import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Basic user schema from the original file
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Crime incident records for Thoothukudi
export const crimeIncidents = pgTable("crime_incidents", {
  id: serial("id").primaryKey(),
  incident_type: text("incident_type").notNull(), // e.g., "theft", "assault", "harassment"
  severity: integer("severity").notNull(), // 1-10, higher is more severe
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  incident_date: timestamp("incident_date").notNull(),
  time_of_day: text("time_of_day").notNull(), // e.g., "morning", "afternoon", "evening", "night"
  description: text("description"),
  reported_by: text("reported_by"), // could be "police", "user", "news"
  verified: boolean("verified").default(false),
});

export const insertCrimeIncidentSchema = createInsertSchema(crimeIncidents).pick({
  incident_type: true,
  severity: true,
  latitude: true,
  longitude: true,
  incident_date: true,
  time_of_day: true,
  description: true,
  reported_by: true,
  verified: true,
});

export type InsertCrimeIncident = z.infer<typeof insertCrimeIncidentSchema>;
export type CrimeIncident = typeof crimeIncidents.$inferSelect;

// SafeRoute schemas
export const safetyScores = pgTable("safety_scores", {
  id: serial("id").primaryKey(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  score: integer("score").notNull(), // 1-100, higher is safer
  time_of_day: text("time_of_day").notNull(), // e.g., "day", "night"
  lighting_level: integer("lighting_level").notNull(), // 1-10
  foot_traffic: integer("foot_traffic").notNull(), // 1-10
  has_cameras: boolean("has_cameras").default(false),
  police_proximity: integer("police_proximity").notNull(), // distance in meters to nearest police station
});

export const insertSafetyScoreSchema = createInsertSchema(safetyScores).pick({
  latitude: true,
  longitude: true,
  score: true,
  time_of_day: true,
  lighting_level: true,
  foot_traffic: true,
  has_cameras: true,
  police_proximity: true,
});

export type InsertSafetyScore = z.infer<typeof insertSafetyScoreSchema>;
export type SafetyScore = typeof safetyScores.$inferSelect;

export const serviceLocations = pgTable("service_locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  latitude: doublePrecision("latitude").notNull(),
  longitude: doublePrecision("longitude").notNull(),
  type: text("type").notNull(), // "police", "hospital", "restaurant"
  description: text("description"),
  address: text("address"),
  contact: text("contact"),
  operating_hours: text("operating_hours"),
});

export const insertServiceLocationSchema = createInsertSchema(serviceLocations).pick({
  name: true,
  latitude: true,
  longitude: true,
  type: true,
  description: true,
  address: true,
  contact: true,
  operating_hours: true,
});

export type InsertServiceLocation = z.infer<typeof insertServiceLocationSchema>;
export type ServiceLocation = typeof serviceLocations.$inferSelect;

export const routes = pgTable("routes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  safety_level: text("safety_level").notNull(), // "safe", "moderate", "danger"
  distance: doublePrecision("distance").notNull(), // in miles
  duration: integer("duration").notNull(), // in minutes
  coordinates: text("coordinates").notNull(), // JSON string of coordinates
  safety_score: integer("safety_score").notNull(), // 1-100, calculated from safety_scores
  lighting: text("lighting").notNull(), // "well-lit", "partially lit", "poor lighting"
  foot_traffic: text("foot_traffic").notNull(), // "high", "moderate", "low"
});

export const insertRouteSchema = createInsertSchema(routes).pick({
  name: true,
  safety_level: true,
  distance: true,
  duration: true,
  coordinates: true,
  safety_score: true,
  lighting: true,
  foot_traffic: true,
});

export type InsertRoute = z.infer<typeof insertRouteSchema>;
export type Route = typeof routes.$inferSelect;

// GeoJSON type definitions for the frontend
export type Point = {
  type: "Point";
  coordinates: [number, number]; // [longitude, latitude]
};

export type LineString = {
  type: "LineString";
  coordinates: Array<[number, number]>; // Array of [longitude, latitude]
};

export type GeoJSONFeature<G, P> = {
  type: "Feature";
  geometry: G;
  properties: P;
};

export type RouteProperties = {
  name: string;
  safety_level: "safe" | "moderate" | "danger";
  distance: number;
  duration: number;
  safety_score: number;
  lighting: string;
  foot_traffic: string;
};

export type ServiceProperties = {
  name: string;
  type: "police" | "hospital" | "restaurant";
  description?: string;
  address?: string;
  contact?: string;
  operating_hours?: string;
};

export type RouteGeoJSON = GeoJSONFeature<LineString, RouteProperties>;
export type ServiceGeoJSON = GeoJSONFeature<Point, ServiceProperties>;
