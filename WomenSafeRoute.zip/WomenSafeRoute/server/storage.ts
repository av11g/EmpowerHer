import { 
  users, type User, type InsertUser,
  safetyScores, type SafetyScore, type InsertSafetyScore,
  serviceLocations, type ServiceLocation, type InsertServiceLocation,
  routes, type Route, type InsertRoute,
  crimeIncidents, type CrimeIncident, type InsertCrimeIncident
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte } from "drizzle-orm";

// Storage interface with all required CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Safety score methods
  createSafetyScore(score: InsertSafetyScore): Promise<SafetyScore>;
  getSafetyScore(id: number): Promise<SafetyScore | undefined>;
  getAllSafetyScores(): Promise<SafetyScore[]>;
  
  // Service location methods
  createServiceLocation(location: InsertServiceLocation): Promise<ServiceLocation>;
  getServiceLocation(id: number): Promise<ServiceLocation | undefined>;
  getAllServiceLocations(): Promise<ServiceLocation[]>;
  getServiceLocationsByType(type: string): Promise<ServiceLocation[]>;
  
  // Route methods
  createRoute(route: InsertRoute): Promise<Route>;
  getRoute(id: number): Promise<Route | undefined>;
  getAllRoutes(): Promise<Route[]>;
  
  // Crime incident methods
  createCrimeIncident(incident: InsertCrimeIncident): Promise<CrimeIncident>;
  getCrimeIncident(id: number): Promise<CrimeIncident | undefined>;
  getAllCrimeIncidents(): Promise<CrimeIncident[]>;
  getCrimeIncidentsByType(type: string): Promise<CrimeIncident[]>;
  getCrimeIncidentsByDateRange(startDate: Date, endDate: Date): Promise<CrimeIncident[]>;
  getCrimeIncidentsByLocation(lat: number, lng: number, radiusKm: number): Promise<CrimeIncident[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private safetyScores: Map<number, SafetyScore>;
  private serviceLocations: Map<number, ServiceLocation>;
  private routes: Map<number, Route>;
  private crimeIncidents: Map<number, CrimeIncident>;
  
  private userIdCounter: number;
  private scoreIdCounter: number;
  private locationIdCounter: number;
  private routeIdCounter: number;
  private incidentIdCounter: number;

  constructor() {
    this.users = new Map();
    this.safetyScores = new Map();
    this.serviceLocations = new Map();
    this.routes = new Map();
    this.crimeIncidents = new Map();
    
    this.userIdCounter = 1;
    this.scoreIdCounter = 1;
    this.locationIdCounter = 1;
    this.routeIdCounter = 1;
    this.incidentIdCounter = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Safety score methods
  async createSafetyScore(insertScore: InsertSafetyScore): Promise<SafetyScore> {
    const id = this.scoreIdCounter++;
    // Ensure has_cameras is explicitly a boolean or null, not undefined
    const safetyScore = {
      ...insertScore,
      has_cameras: insertScore.has_cameras === undefined ? null : insertScore.has_cameras,
      id
    };
    this.safetyScores.set(id, safetyScore as SafetyScore);
    return safetyScore as SafetyScore;
  }
  
  async getSafetyScore(id: number): Promise<SafetyScore | undefined> {
    return this.safetyScores.get(id);
  }
  
  async getAllSafetyScores(): Promise<SafetyScore[]> {
    return Array.from(this.safetyScores.values());
  }
  
  // Service location methods
  async createServiceLocation(insertLocation: InsertServiceLocation): Promise<ServiceLocation> {
    const id = this.locationIdCounter++;
    // Ensure optional fields are explicitly string or null, not undefined
    const serviceLocation = {
      ...insertLocation,
      description: insertLocation.description || null,
      address: insertLocation.address || null,
      contact: insertLocation.contact || null,
      operating_hours: insertLocation.operating_hours || null,
      id
    };
    this.serviceLocations.set(id, serviceLocation as ServiceLocation);
    return serviceLocation as ServiceLocation;
  }
  
  async getServiceLocation(id: number): Promise<ServiceLocation | undefined> {
    return this.serviceLocations.get(id);
  }
  
  async getAllServiceLocations(): Promise<ServiceLocation[]> {
    return Array.from(this.serviceLocations.values());
  }
  
  async getServiceLocationsByType(type: string): Promise<ServiceLocation[]> {
    return Array.from(this.serviceLocations.values()).filter(
      location => location.type === type
    );
  }
  
  // Route methods
  async createRoute(insertRoute: InsertRoute): Promise<Route> {
    const id = this.routeIdCounter++;
    const route: Route = { ...insertRoute, id };
    this.routes.set(id, route);
    return route;
  }
  
  async getRoute(id: number): Promise<Route | undefined> {
    return this.routes.get(id);
  }
  
  async getAllRoutes(): Promise<Route[]> {
    return Array.from(this.routes.values());
  }

  // Crime incident methods
  async createCrimeIncident(insertIncident: InsertCrimeIncident): Promise<CrimeIncident> {
    const id = this.incidentIdCounter++;
    // Ensure optional fields are explicitly string or null, not undefined
    const crimeIncident = {
      ...insertIncident,
      description: insertIncident.description || null,
      reported_by: insertIncident.reported_by || null,
      verified: insertIncident.verified ?? false,
      id
    };
    this.crimeIncidents.set(id, crimeIncident as CrimeIncident);
    return crimeIncident as CrimeIncident;
  }
  
  async getCrimeIncident(id: number): Promise<CrimeIncident | undefined> {
    return this.crimeIncidents.get(id);
  }
  
  async getAllCrimeIncidents(): Promise<CrimeIncident[]> {
    return Array.from(this.crimeIncidents.values());
  }
  
  async getCrimeIncidentsByType(type: string): Promise<CrimeIncident[]> {
    return Array.from(this.crimeIncidents.values()).filter(
      incident => incident.incident_type === type
    );
  }
  
  async getCrimeIncidentsByDateRange(startDate: Date, endDate: Date): Promise<CrimeIncident[]> {
    return Array.from(this.crimeIncidents.values()).filter(incident => {
      const incidentDate = new Date(incident.incident_date);
      return incidentDate >= startDate && incidentDate <= endDate;
    });
  }
  
  async getCrimeIncidentsByLocation(lat: number, lng: number, radiusKm: number): Promise<CrimeIncident[]> {
    return Array.from(this.crimeIncidents.values()).filter(incident => {
      const latDiff = Math.abs(incident.latitude - lat);
      const lngDiff = Math.abs(incident.longitude - lng);
      
      // Rough approximation of distance using Pythagoras' theorem
      // This is not accurate for large distances or near the poles,
      // but works as a simple demo for reasonably small radiuses
      const approxDistance = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111; // 111 km per degree
      
      return approxDistance <= radiusKm;
    });
  }
}

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  // Safety score methods
  async createSafetyScore(insertScore: InsertSafetyScore): Promise<SafetyScore> {
    const scoreData = {
      ...insertScore,
      has_cameras: insertScore.has_cameras === undefined ? false : insertScore.has_cameras,
    };
    
    const [safetyScore] = await db
      .insert(safetyScores)
      .values(scoreData)
      .returning();
      
    return safetyScore;
  }
  
  async getSafetyScore(id: number): Promise<SafetyScore | undefined> {
    const [score] = await db.select().from(safetyScores).where(eq(safetyScores.id, id));
    return score || undefined;
  }
  
  async getAllSafetyScores(): Promise<SafetyScore[]> {
    return await db.select().from(safetyScores);
  }
  
  // Service location methods
  async createServiceLocation(insertLocation: InsertServiceLocation): Promise<ServiceLocation> {
    const [serviceLocation] = await db
      .insert(serviceLocations)
      .values(insertLocation)
      .returning();
      
    return serviceLocation;
  }
  
  async getServiceLocation(id: number): Promise<ServiceLocation | undefined> {
    const [location] = await db.select().from(serviceLocations).where(eq(serviceLocations.id, id));
    return location || undefined;
  }
  
  async getAllServiceLocations(): Promise<ServiceLocation[]> {
    return await db.select().from(serviceLocations);
  }
  
  async getServiceLocationsByType(type: string): Promise<ServiceLocation[]> {
    return await db.select().from(serviceLocations).where(eq(serviceLocations.type, type));
  }
  
  // Route methods
  async createRoute(insertRoute: InsertRoute): Promise<Route> {
    const [route] = await db
      .insert(routes)
      .values(insertRoute)
      .returning();
      
    return route;
  }
  
  async getRoute(id: number): Promise<Route | undefined> {
    const [route] = await db.select().from(routes).where(eq(routes.id, id));
    return route || undefined;
  }
  
  async getAllRoutes(): Promise<Route[]> {
    return await db.select().from(routes);
  }
  
  // Crime incident methods
  async createCrimeIncident(incident: InsertCrimeIncident): Promise<CrimeIncident> {
    const [crimeIncident] = await db
      .insert(crimeIncidents)
      .values(incident)
      .returning();
      
    return crimeIncident;
  }
  
  async getCrimeIncident(id: number): Promise<CrimeIncident | undefined> {
    const [incident] = await db.select().from(crimeIncidents).where(eq(crimeIncidents.id, id));
    return incident || undefined;
  }
  
  async getAllCrimeIncidents(): Promise<CrimeIncident[]> {
    return await db.select().from(crimeIncidents);
  }
  
  async getCrimeIncidentsByType(type: string): Promise<CrimeIncident[]> {
    return await db.select().from(crimeIncidents).where(eq(crimeIncidents.incident_type, type));
  }
  
  async getCrimeIncidentsByDateRange(startDate: Date, endDate: Date): Promise<CrimeIncident[]> {
    return await db.select().from(crimeIncidents).where(
      and(
        gte(crimeIncidents.incident_date, startDate),
        lte(crimeIncidents.incident_date, endDate)
      )
    );
  }
  
  async getCrimeIncidentsByLocation(lat: number, lng: number, radiusKm: number): Promise<CrimeIncident[]> {
    // This is a simplified implementation. For a real app, we would use a proper geo query
    // with PostGIS. For now, we'll use a rough approximation where 0.01 degrees is about 1.1 km
    const approxDegreesRadius = radiusKm / 111;
    
    const incidents = await db.select().from(crimeIncidents);
    
    // Filter incidents in-memory based on approximate distance
    return incidents.filter(incident => {
      const latDiff = Math.abs(incident.latitude - lat);
      const lngDiff = Math.abs(incident.longitude - lng);
      
      // Rough approximation of distance using Pythagoras' theorem
      // This is not accurate for large distances or near the poles,
      // but works as a simple demo for reasonably small radiuses
      const approxDistance = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111; // 111 km per degree
      
      return approxDistance <= radiusKm;
    });
  }
}

// Switch to database storage
export const storage = new DatabaseStorage();
