import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from 'ws';
import { storage } from "./storage";
import { type SafetyScore, type ServiceLocation, type Route, type CrimeIncident, type InsertCrimeIncident } from "@shared/schema";

// Sample data for Thoothukudi, India
const sampleSafetyScores = [
  {
    latitude: 8.7638,  // Thoothukudi Central area
    longitude: 78.1348,
    score: 80,
    time_of_day: "day",
    lighting_level: 7,
    foot_traffic: 8,
    has_cameras: true,
    police_proximity: 400
  },
  {
    latitude: 8.7642,  // Near Anna Nagar
    longitude: 78.1328,
    score: 60,
    time_of_day: "night",
    lighting_level: 5,
    foot_traffic: 4,
    has_cameras: false,
    police_proximity: 900
  },
  {
    latitude: 8.7599,  // Near VVD Signal area
    longitude: 78.1354,
    score: 45,
    time_of_day: "night",
    lighting_level: 3,
    foot_traffic: 2,
    has_cameras: false,
    police_proximity: 1100
  },
  {
    latitude: 8.7712,  // Third Mile area
    longitude: 78.1343,
    score: 70,
    time_of_day: "day",
    lighting_level: 6,
    foot_traffic: 7,
    has_cameras: true,
    police_proximity: 600
  },
  {
    latitude: 8.7541,  // Millerpuram area
    longitude: 78.1308,
    score: 65,
    time_of_day: "evening",
    lighting_level: 5,
    foot_traffic: 6,
    has_cameras: true,
    police_proximity: 850
  }
];

const sampleServiceLocations = [
  {
    name: "Thoothukudi District Police Office",
    latitude: 8.7643,
    longitude: 78.1336,
    type: "police",
    description: "District Police Headquarters with 24/7 emergency services",
    address: "Palayamkottai Road, Thoothukudi",
    contact: "100",
    operating_hours: "24/7"
  },
  {
    name: "Thoothukudi North Police Station",
    latitude: 8.7655,
    longitude: 78.1320,
    type: "police",
    description: "Police station serving the Northern part of Thoothukudi",
    address: "North Main Road, Thoothukudi",
    contact: "0461-2320046",
    operating_hours: "24/7"
  },
  {
    name: "Thoothukudi Medical College Hospital",
    latitude: 8.7836,
    longitude: 78.1248,
    type: "hospital",
    description: "Government Medical College & Hospital with 24/7 emergency services",
    address: "Palayamkottai Road, Thoothukudi",
    contact: "0461-2320002",
    operating_hours: "24/7"
  },
  {
    name: "Holy Cross Hospital",
    latitude: 8.7611,
    longitude: 78.1392,
    type: "hospital",
    description: "Private hospital with emergency services",
    address: "Trespuram, Thoothukudi",
    contact: "0461-2320129",
    operating_hours: "24/7"
  },
  {
    name: "Hotel Aryaas",
    latitude: 8.7637,
    longitude: 78.1360,
    type: "restaurant",
    description: "Popular South Indian vegetarian restaurant",
    address: "WGC Road, Thoothukudi",
    contact: "0461-2320567",
    operating_hours: "7am-10:30pm"
  },
  {
    name: "Bell Hotel Restaurant",
    latitude: 8.7625,
    longitude: 78.1389,
    type: "restaurant",
    description: "Multi-cuisine restaurant offering local specialties",
    address: "Palayamkottai Road, Thoothukudi",
    contact: "0461-2328899",
    operating_hours: "11am-11pm"
  },
  {
    name: "Thoothukudi South Police Station",
    latitude: 8.7550,
    longitude: 78.1347,
    type: "police",
    description: "Police station serving the Southern part of Thoothukudi",
    address: "South Main Road, Thoothukudi",
    contact: "0461-2320092",
    operating_hours: "24/7"
  },
  {
    name: "Kamaraj College Health Center",
    latitude: 8.7520,
    longitude: 78.1267,
    type: "hospital",
    description: "College health center providing basic medical services",
    address: "Kamaraj College Road, Thoothukudi",
    contact: "0461-2312264",
    operating_hours: "8am-6pm"
  },
  {
    name: "Café Coffee Day",
    latitude: 8.7630,
    longitude: 78.1362,
    type: "restaurant",
    description: "Popular café chain offering coffee and light snacks",
    address: "Palayamkottai Road, Thoothukudi",
    contact: "0461-2312543",
    operating_hours: "9am-11pm"
  }
];

const sampleRoutes = [
  {
    name: "Safest Route: Central to VOC Port",
    safety_level: "safe",
    distance: 3.2,
    duration: 35,
    coordinates: JSON.stringify([
      [78.1348, 8.7638], // Thoothukudi Central
      [78.1370, 8.7620],
      [78.1390, 8.7580],
      [78.1430, 8.7558] // VOC Port
    ]),
    safety_score: 85,
    lighting: "well-lit",
    foot_traffic: "high"
  },
  {
    name: "Faster Route: Central to VOC Port",
    safety_level: "moderate",
    distance: 2.8,
    duration: 30,
    coordinates: JSON.stringify([
      [78.1348, 8.7638], // Thoothukudi Central
      [78.1380, 8.7600],
      [78.1410, 8.7570],
      [78.1430, 8.7558] // VOC Port
    ]),
    safety_score: 65,
    lighting: "partially lit",
    foot_traffic: "moderate"
  },
  {
    name: "Shortest Route: Central to VOC Port",
    safety_level: "danger",
    distance: 2.5,
    duration: 25,
    coordinates: JSON.stringify([
      [78.1348, 8.7638], // Thoothukudi Central
      [78.1390, 8.7600],
      [78.1420, 8.7570],
      [78.1430, 8.7558] // VOC Port
    ]),
    safety_score: 40,
    lighting: "poor lighting",
    foot_traffic: "low"
  },
  {
    name: "Safest Route: Central to Medical College",
    safety_level: "safe",
    distance: 3.5,
    duration: 38,
    coordinates: JSON.stringify([
      [78.1348, 8.7638], // Thoothukudi Central
      [78.1330, 8.7680],
      [78.1290, 8.7750],
      [78.1248, 8.7836] // Medical College
    ]),
    safety_score: 80,
    lighting: "well-lit",
    foot_traffic: "high"
  },
  {
    name: "Coastal Route: Central to Harbor Beach",
    safety_level: "moderate",
    distance: 4.0,
    duration: 45,
    coordinates: JSON.stringify([
      [78.1348, 8.7638], // Thoothukudi Central
      [78.1390, 8.7620],
      [78.1430, 8.7590],
      [78.1472, 8.7510] // Harbor Beach
    ]),
    safety_score: 70,
    lighting: "partially lit",
    foot_traffic: "moderate"
  }
];

// Sample crime incidents for Thoothukudi
const sampleCrimeIncidents = [
  {
    incident_type: "theft",
    severity: 6,
    latitude: 8.7620,
    longitude: 78.1367,
    incident_date: new Date("2024-02-15T21:30:00"),
    time_of_day: "night",
    description: "Mobile phone snatching near bus stand",
    reported_by: "police",
    verified: true
  },
  {
    incident_type: "harassment",
    severity: 5,
    latitude: 8.7645,
    longitude: 78.1342,
    incident_date: new Date("2024-02-20T19:45:00"),
    time_of_day: "evening",
    description: "Verbal harassment reported by female pedestrian",
    reported_by: "user",
    verified: true
  },
  {
    incident_type: "assault",
    severity: 8,
    latitude: 8.7590,
    longitude: 78.1380,
    incident_date: new Date("2024-01-30T23:20:00"),
    time_of_day: "night",
    description: "Physical assault reported near abandoned building",
    reported_by: "police",
    verified: true
  },
  {
    incident_type: "theft",
    severity: 4,
    latitude: 8.7635,
    longitude: 78.1355,
    incident_date: new Date("2024-03-05T16:15:00"),
    time_of_day: "afternoon",
    description: "Purse snatching in crowded market area",
    reported_by: "user",
    verified: true
  },
  {
    incident_type: "vandalism",
    severity: 3,
    latitude: 8.7580,
    longitude: 78.1330,
    incident_date: new Date("2024-03-10T02:30:00"),
    time_of_day: "night",
    description: "Property damage to shop fronts",
    reported_by: "police",
    verified: true
  },
  {
    incident_type: "harassment",
    severity: 6,
    latitude: 8.7710,
    longitude: 78.1335,
    incident_date: new Date("2024-02-28T18:40:00"),
    time_of_day: "evening",
    description: "Group harassment of female college students",
    reported_by: "user",
    verified: true
  },
  {
    incident_type: "theft",
    severity: 5,
    latitude: 8.7570,
    longitude: 78.1365,
    incident_date: new Date("2024-03-12T14:20:00"),
    time_of_day: "afternoon",
    description: "Theft from parked vehicle",
    reported_by: "police",
    verified: true
  }
];

export async function registerRoutes(app: Express): Promise<Server> {
  // API endpoint to provide secure environment variables to the client
  app.get('/api/config', (_req, res) => {
    // Only expose necessary environment variables (never expose sensitive secrets)
    res.json({
      mapbox: {
        accessToken: process.env.MAPBOX_TOKEN || ''
      },
      googleMaps: {
        apiKey: process.env.GOOGLE_MAPS_API_KEY || ''
      }
    });
  });

  // Initialize sample data
  const initializeSampleData = async () => {
    // Add safety scores
    for (const score of sampleSafetyScores) {
      await storage.createSafetyScore(score);
    }
    
    // Add service locations
    for (const location of sampleServiceLocations) {
      await storage.createServiceLocation(location);
    }
    
    // Add routes
    for (const route of sampleRoutes) {
      await storage.createRoute(route);
    }
    
    // Add crime incidents
    for (const incident of sampleCrimeIncidents) {
      await storage.createCrimeIncident(incident);
    }
  };
  
  initializeSampleData();

  // API endpoints
  app.get('/api/safety-scores', async (_req, res) => {
    try {
      const scores = await storage.getAllSafetyScores();
      res.json(scores);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching safety scores' });
    }
  });

  app.get('/api/service-locations', async (req, res) => {
    try {
      const type = req.query.type as string | undefined;
      const locations = type 
        ? await storage.getServiceLocationsByType(type)
        : await storage.getAllServiceLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching service locations' });
    }
  });

  app.get('/api/routes', async (_req, res) => {
    try {
      const routes = await storage.getAllRoutes();
      res.json(routes);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching routes' });
    }
  });

  app.get('/api/routes/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      const route = await storage.getRoute(id);
      
      if (!route) {
        return res.status(404).json({ message: 'Route not found' });
      }
      
      res.json(route);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching route' });
    }
  });
  
  // Crime incident endpoints
  app.get('/api/crime-incidents', async (req, res) => {
    try {
      const type = req.query.type as string | undefined;
      
      let incidents: CrimeIncident[] = [];
      
      if (type) {
        incidents = await storage.getCrimeIncidentsByType(type);
      } else {
        incidents = await storage.getAllCrimeIncidents();
      }
      
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching crime incidents' });
    }
  });
  
  app.get('/api/crime-incidents/:id', async (req, res) => {
    try {
      const id = Number(req.params.id);
      const incident = await storage.getCrimeIncident(id);
      
      if (!incident) {
        return res.status(404).json({ message: 'Crime incident not found' });
      }
      
      res.json(incident);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching crime incident' });
    }
  });
  
  app.get('/api/crime-incidents/by-date-range', async (req, res) => {
    try {
      const startDate = req.query.start ? new Date(req.query.start as string) : new Date(0);
      const endDate = req.query.end ? new Date(req.query.end as string) : new Date();
      
      const incidents = await storage.getCrimeIncidentsByDateRange(startDate, endDate);
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching crime incidents by date range' });
    }
  });
  
  app.get('/api/crime-incidents/by-location', async (req, res) => {
    try {
      const lat = Number(req.query.lat);
      const lng = Number(req.query.lng);
      const radius = Number(req.query.radius) || 1; // Default 1km radius
      
      if (isNaN(lat) || isNaN(lng)) {
        return res.status(400).json({ message: 'Invalid latitude or longitude' });
      }
      
      const incidents = await storage.getCrimeIncidentsByLocation(lat, lng, radius);
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: 'Error fetching crime incidents by location' });
    }
  });

  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Connected clients
  const clients = new Set<WebSocket>();

  // WebSocket connection handler
  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    clients.add(ws);

    // Send initial data to the client
    const sendInitialData = async () => {
      try {
        const safetyScores = await storage.getAllSafetyScores();
        const serviceLocations = await storage.getAllServiceLocations();
        const routes = await storage.getAllRoutes();
        const crimeIncidents = await storage.getAllCrimeIncidents();

        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'initial_data',
            data: {
              safetyScores,
              serviceLocations,
              routes,
              crimeIncidents
            }
          }));
          
          // If there are crime incidents, send a specific crime incident alert too
          if (crimeIncidents.length > 0) {
            ws.send(JSON.stringify({
              type: 'crime_incident_alert',
              data: {
                crimeIncidents,
                timestamp: new Date().toISOString()
              }
            }));
          }
        }
      } catch (error) {
        console.error('Error sending initial data:', error);
      }
    };

    sendInitialData();

    // Handle real-time location updates from client
    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        // Handle different message types
        if (data.type === 'location_update') {
          // Client sent their current location
          const { latitude, longitude } = data.data;
          
          // Find nearby safety scores and send real-time safety alerts
          const nearbyScores = await storage.getAllSafetyScores();
          const nearbyServiceLocations = await storage.getAllServiceLocations();
          
          // Get nearby crime incidents
          const nearbyCrimeIncidents = await storage.getCrimeIncidentsByLocation(latitude, longitude, 1); // 1km radius
          
          // Calculate closest emergency services based on location
          const emergencyServices = nearbyServiceLocations
            .filter(loc => loc.type === 'police' || loc.type === 'hospital')
            .map(loc => {
              // Calculate rough distance (this is simplified - in production use proper geo-distance)
              const distance = Math.sqrt(
                Math.pow(loc.latitude - latitude, 2) + 
                Math.pow(loc.longitude - longitude, 2)
              ) * 111; // Rough conversion to km
              
              return {
                ...loc,
                distance: distance.toFixed(2)
              };
            })
            .sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance))
            .slice(0, 3); // Get 3 closest emergency services
          
          // Send safety information based on current location
          if (ws.readyState === WebSocket.OPEN) {
            // First send emergency services information
            ws.send(JSON.stringify({
              type: 'safety_alert',
              data: {
                nearbyScores,
                emergencyServices,
                timestamp: new Date().toISOString()
              }
            }));
            
            // Then send crime incidents as a separate message for better client-side handling
            if (nearbyCrimeIncidents.length > 0) {
              ws.send(JSON.stringify({
                type: 'crime_incident_alert',
                data: {
                  crimeIncidents: nearbyCrimeIncidents,
                  timestamp: new Date().toISOString()
                }
              }));
            }
          }
        } else if (data.type === 'emergency_alert') {
          // Handle emergency alerts - broadcast to all connected clients
          // This could be used for community alerts
          const { alertType, message, location } = data.data;
          
          // Broadcast to all connected clients
          clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(JSON.stringify({
                type: 'community_alert',
                data: {
                  alertType,
                  message,
                  location,
                  timestamp: new Date().toISOString()
                }
              }));
            }
          });
        }
      } catch (error) {
        console.error('Error processing WebSocket message:', error);
      }
    });

    // Setup periodic safety updates (simulating real-time data)
    const safetyUpdateInterval = setInterval(async () => {
      try {
        if (ws.readyState !== WebSocket.OPEN) {
          clearInterval(safetyUpdateInterval);
          return;
        }
        
        // Get random safety score to update (simulating real-time changes)
        const scores = await storage.getAllSafetyScores();
        if (scores.length > 0) {
          const randomIndex = Math.floor(Math.random() * scores.length);
          const scoreToUpdate = scores[randomIndex];
          
          // Simulate time-based safety score changes
          const hourOfDay = new Date().getHours();
          let updatedScore = scoreToUpdate.score;
          
          // Safety decreases at night (6pm-6am)
          if (hourOfDay >= 18 || hourOfDay < 6) {
            updatedScore = Math.max(30, scoreToUpdate.score - Math.floor(Math.random() * 15));
          } else {
            // Safety increases during day
            updatedScore = Math.min(95, scoreToUpdate.score + Math.floor(Math.random() * 10));
          }
          
          const updatedSafetyScore = {
            ...scoreToUpdate,
            score: updatedScore,
            time_of_day: hourOfDay >= 18 || hourOfDay < 6 ? 'night' : 
                        (hourOfDay >= 6 && hourOfDay < 10) ? 'morning' : 
                        (hourOfDay >= 10 && hourOfDay < 17) ? 'day' : 'evening',
            lighting_level: hourOfDay >= 18 || hourOfDay < 6 ? 
                          Math.floor(Math.random() * 5) + 3 : 
                          Math.floor(Math.random() * 3) + 7
          };
          
          // Send real-time update
          ws.send(JSON.stringify({
            type: 'safety_score_update',
            data: updatedSafetyScore
          }));
        }
      } catch (error) {
        console.error('Error sending safety update:', error);
      }
    }, 30000); // Update every 30 seconds
    
    // Occasionally simulate new crime incidents (less frequently than safety updates)
    const crimeIncidentInterval = setInterval(async () => {
      try {
        if (ws.readyState !== WebSocket.OPEN) {
          clearInterval(crimeIncidentInterval);
          return;
        }
        
        // Only simulate incidents occasionally (20% chance each interval)
        if (Math.random() < 0.2) {
          // Get existing safety scores to use their locations
          const scores = await storage.getAllSafetyScores();
          if (scores.length > 0) {
            // Pick a random safety score location to use as the crime incident location
            const randomIndex = Math.floor(Math.random() * scores.length);
            const locationSource = scores[randomIndex];
            
            // Slightly randomize the location
            const latitude = locationSource.latitude + (Math.random() * 0.005 - 0.0025);
            const longitude = locationSource.longitude + (Math.random() * 0.005 - 0.0025);
            
            // Incident types and descriptions
            const incidentTypes = ['theft', 'harassment', 'vandalism', 'assault'];
            const descriptions = [
              'Smartphone theft reported',
              'Verbal harassment reported by pedestrian',
              'Wallet snatching incident',
              'Purse theft reported',
              'Vandalism to shop fronts',
              'Verbal altercation between pedestrians',
              'Suspicious individuals reported'
            ];
            
            // Time of day based on current hour
            const hourOfDay = new Date().getHours();
            const timeOfDay = hourOfDay >= 18 || hourOfDay < 6 ? 'night' : 
                            (hourOfDay >= 6 && hourOfDay < 10) ? 'morning' : 
                            (hourOfDay >= 10 && hourOfDay < 17) ? 'day' : 'evening';
            
            // Create new incident
            const newIncident: InsertCrimeIncident = {
              incident_type: incidentTypes[Math.floor(Math.random() * incidentTypes.length)],
              severity: Math.floor(Math.random() * 6) + 3, // 3-8 severity
              latitude,
              longitude,
              incident_date: new Date(),
              time_of_day: timeOfDay,
              description: descriptions[Math.floor(Math.random() * descriptions.length)],
              reported_by: Math.random() > 0.5 ? 'user' : 'police',
              verified: true
            };
            
            // Save the incident to storage
            const savedIncident = await storage.createCrimeIncident(newIncident);
            
            // Send crime incident alert to client
            ws.send(JSON.stringify({
              type: 'crime_incident_alert',
              data: {
                crimeIncidents: [savedIncident],
                timestamp: new Date().toISOString(),
                isNew: true
              }
            }));
          }
        }
      } catch (error) {
        console.error('Error simulating crime incident:', error);
      }
    }, 60000); // Check every 60 seconds

    // Handle disconnection
    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clients.delete(ws);
      clearInterval(safetyUpdateInterval);
      clearInterval(crimeIncidentInterval);
    });
  });

  return httpServer;
}
