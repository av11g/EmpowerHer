import React, { useEffect } from 'react';
import MapWrapper from '@/components/saferoute/MapWrapper';
import MapControls from '@/components/saferoute/MapControls';
import FilterOptions from '@/components/saferoute/FilterOptions';
import SidePanel from '@/components/saferoute/SidePanel';
import RouteDetailsSheet from '@/components/saferoute/RouteDetailsSheet';
import DesktopRoutePanel from '@/components/saferoute/DesktopRoutePanel';
import EmergencyButton from '@/components/saferoute/EmergencyButton';
import SafetyNotifications from '@/components/saferoute/SafetyNotifications';
import { useSafetyMap } from '@/hooks/use-safety-map';
import { useWebSocket } from '@/hooks/use-websocket';
import { MapProviderProvider } from '@/hooks/use-map-provider';

const Home: React.FC = () => {
  const {
    mapRef,
    routes,
    isLoadingRoutes,
    serviceLocations,
    isLoadingServices,
    selectedRoute,
    selectRoute,
    visibleServiceTypes,
    toggleServiceType,
    isSidebarOpen,
    toggleSidebar,
    isBottomSheetOpen,
    toggleBottomSheet,
    routeGeoJSON,
    serviceGeoJSON
  } = useSafetyMap();
  
  const { sendLocationUpdate } = useWebSocket();
  
  // Simulate sending periodic location updates
  useEffect(() => {
    // Send initial location update (Thoothukudi, India)
    sendLocationUpdate(8.7638, 78.1348);
    
    // Set up periodic location updates to simulate movement
    const locationUpdateInterval = setInterval(() => {
      // Simulate small random movement around Thoothukudi
      const randomLat = 8.7638 + (Math.random() - 0.5) * 0.003;
      const randomLng = 78.1348 + (Math.random() - 0.5) * 0.003;
      
      sendLocationUpdate(randomLat, randomLng);
    }, 60000); // Update every minute
    
    return () => clearInterval(locationUpdateInterval);
  }, [sendLocationUpdate]);

  return (
    <MapProviderProvider>
      <div className="relative h-screen flex flex-row">
        {/* Left Side Panel */}
        <SidePanel 
          isOpen={isSidebarOpen}
          toggleSidebar={toggleSidebar}
        />

        {/* Main Content */}
        <div className="flex-1 flex flex-col md:flex-row relative">
          {/* The Map Component Container */}
          <MapWrapper />

          {/* Map Controls Overlay */}
          <MapControls toggleSidebar={toggleSidebar} />

          {/* Filter Options */}
          <FilterOptions 
            visibleServiceTypes={visibleServiceTypes}
            toggleServiceType={toggleServiceType}
          />

          {/* Bottom Route Details Sheet (Mobile) */}
          <RouteDetailsSheet 
            isOpen={isBottomSheetOpen}
            toggleBottomSheet={toggleBottomSheet}
            routes={routes}
            selectedRoute={selectedRoute}
            selectRoute={selectRoute}
          />

          {/* Desktop Route Panel - Now on right side */}
          <DesktopRoutePanel 
            routes={routes}
            selectedRoute={selectedRoute}
            selectRoute={selectRoute}
            serviceLocations={serviceLocations}
          />

          {/* Emergency Floating Action Button */}
          <EmergencyButton />
          
          {/* Real-time Safety Notifications */}
          <SafetyNotifications />
        </div>
      </div>
    </MapProviderProvider>
  );
};

export default Home;
