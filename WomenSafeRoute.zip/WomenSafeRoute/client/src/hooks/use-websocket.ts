import { useState, useEffect, useCallback, useRef } from 'react';
import { type SafetyScore, type ServiceLocation, type Route, type CrimeIncident } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';
import { useIsMobile } from '@/hooks/use-mobile';

interface WebSocketHookReturn {
  isConnected: boolean;
  sendLocationUpdate: (latitude: number, longitude: number) => void;
  sendEmergencyAlert: (message: string, location: { latitude: number, longitude: number }) => void;
  lastSafetyUpdate: SafetyScore | null;
  nearbyEmergencyServices: (ServiceLocation & { distance: string })[] | null;
  nearbyCrimeIncidents: CrimeIncident[] | null;
  communityAlerts: Array<{
    alertType: string;
    message: string;
    location: { latitude: number, longitude: number };
    timestamp: string;
  }>;
}

export const useWebSocket = (): WebSocketHookReturn => {
  // State for tracking connection and received data
  const [isConnected, setIsConnected] = useState(false);
  const [lastSafetyUpdate, setLastSafetyUpdate] = useState<SafetyScore | null>(null);
  const [nearbyEmergencyServices, setNearbyEmergencyServices] = useState<(ServiceLocation & { distance: string })[] | null>(null);
  const [nearbyCrimeIncidents, setNearbyCrimeIncidents] = useState<CrimeIncident[] | null>(null);
  const [communityAlerts, setCommunityAlerts] = useState<Array<{
    alertType: string;
    message: string;
    location: { latitude: number, longitude: number };
    timestamp: string;
  }>>([]);
  
  // References
  const socketRef = useRef<WebSocket | null>(null);
  const locationWatchId = useRef<number | null>(null);
  
  // Hooks
  const { toast } = useToast();
  const isMobile = useIsMobile();
  
  // WebSocket message sending functions
  const sendLocationUpdate = useCallback((latitude: number, longitude: number) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'location_update',
        data: { latitude, longitude }
      }));
    }
  }, []);
  
  const sendEmergencyAlert = useCallback((message: string, location: { latitude: number, longitude: number }) => {
    if (socketRef.current?.readyState === WebSocket.OPEN) {
      socketRef.current.send(JSON.stringify({
        type: 'emergency_alert',
        data: {
          alertType: 'emergency',
          message,
          location
        }
      }));
      
      // Show confirmation toast
      toast({
        title: 'Emergency Alert Sent',
        description: 'Your alert has been sent to nearby users',
      });
    } else {
      toast({
        title: 'Connection Error',
        description: 'Could not send emergency alert - please try again',
        variant: 'destructive',
      });
    }
  }, [toast]);
  
  // Initialize WebSocket connection
  useEffect(() => {
    // Create a simulated WebSocket for development until real-time features are working
    // This allows the UI to work without relying on the WebSocket server
    class SimulatedWebSocket {
      private listeners: { [key: string]: ((event: any) => void)[] } = {};
      readyState = WebSocket.OPEN;
      
      constructor() {
        // Send initial simulated data
        setTimeout(() => {
          this.triggerEvent('open', {});
          
          // Simulate initial data received
          this.triggerEvent('message', { 
            data: JSON.stringify({
              type: 'initial_data',
              data: {
                crimeIncidents: [
                  {
                    id: 1,
                    incident_type: 'theft',
                    severity: 5,
                    latitude: 8.7612,
                    longitude: 78.1332,
                    incident_date: new Date().toISOString(),
                    time_of_day: 'day',
                    description: 'Smartphone theft reported near bus stand',
                    reported_by: 'user',
                    verified: true
                  }
                ]
              }
            })
          });
        }, 1000);
        
        // Simulate periodic safety updates
        setInterval(() => {
          const score = Math.floor(Math.random() * 40) + 60; // Random score between 60-100
          this.triggerEvent('message', {
            data: JSON.stringify({
              type: 'safety_score_update',
              data: {
                id: 1,
                latitude: 8.7638,
                longitude: 78.1348,
                score: score,
                time_of_day: new Date().getHours() >= 18 ? 'night' : 'day',
                lighting_level: 7,
                foot_traffic: 8,
                has_cameras: true,
                police_proximity: 400
              }
            })
          });
        }, 30000);
      }
      
      addEventListener(type: string, callback: (event: any) => void) {
        if (!this.listeners[type]) {
          this.listeners[type] = [];
        }
        this.listeners[type].push(callback);
      }
      
      removeEventListener(type: string, callback: (event: any) => void) {
        if (this.listeners[type]) {
          this.listeners[type] = this.listeners[type].filter(cb => cb !== callback);
        }
      }
      
      send(data: string) {
        // Process received data from client
        try {
          const parsedData = JSON.parse(data);
          
          if (parsedData.type === 'location_update') {
            // Handle location updates
            console.log('Location update sent', parsedData.data);
          } else if (parsedData.type === 'emergency_alert') {
            // Handle emergency alerts
            console.log('Emergency alert sent', parsedData.data);
            
            // Simulate emergency response
            setTimeout(() => {
              this.triggerEvent('message', {
                data: JSON.stringify({
                  type: 'safety_alert',
                  data: {
                    emergencyServices: [
                      {
                        id: 1,
                        name: 'Thoothukudi Police Station',
                        type: 'police',
                        latitude: 8.7640,
                        longitude: 78.1350,
                        contact: '0461-2340180',
                        operating_hours: '24/7',
                        distance: '0.5'
                      },
                      {
                        id: 2,
                        name: 'Government Medical College Hospital',
                        type: 'hospital',
                        latitude: 8.7636,
                        longitude: 78.1248,
                        contact: '0461-2328031',
                        operating_hours: '24/7',
                        distance: '1.2'
                      }
                    ]
                  }
                })
              });
            }, 1500);
          }
        } catch (e) {
          console.error('Error processing message in simulated WebSocket', e);
        }
      }
      
      close() {
        this.triggerEvent('close', {});
        this.listeners = {};
      }
      
      private triggerEvent(type: string, event: any) {
        if (this.listeners[type]) {
          this.listeners[type].forEach(callback => callback(event));
        }
      }
    }
    
    // For development without backend, use simulated WebSocket
    const socket = new SimulatedWebSocket() as unknown as WebSocket;
    socketRef.current = socket;
    
    // Connection opened handler
    const handleOpen = () => {
      console.log('Connected to WebSocket');
      setIsConnected(true);
    };
    
    // Message handler 
    const handleMessage = (event: MessageEvent) => {
      try {
        const message = JSON.parse(event.data);
        
        switch (message.type) {
          case 'initial_data':
            console.log('Received initial data from server');
            // Check if there are any crime incidents in the initial data
            if (message.data && message.data.crimeIncidents) {
              setNearbyCrimeIncidents(message.data.crimeIncidents);
            }
            break;
            
          case 'safety_score_update':
            setLastSafetyUpdate(message.data);
            // Show toast for significant safety changes
            if (message.data.score < 50) {
              toast({
                title: 'Safety Alert',
                description: `Safety level decreased in ${message.data.time_of_day} at [${message.data.latitude.toFixed(4)}, ${message.data.longitude.toFixed(4)}]`,
                variant: 'destructive',
                duration: 5000,
              });
            }
            break;
            
          case 'safety_alert':
            // Update nearby emergency services
            if (message.data.emergencyServices) {
              setNearbyEmergencyServices(message.data.emergencyServices);
            }
            break;
            
          case 'crime_incident_alert':
            // Update nearby crime incidents
            if (message.data.crimeIncidents) {
              setNearbyCrimeIncidents(message.data.crimeIncidents);
              
              // Show a toast for new crime incidents
              if (message.data.crimeIncidents.length > 0) {
                const recentIncident = message.data.crimeIncidents[0];
                toast({
                  title: 'Crime Alert',
                  description: `${recentIncident.incident_type} reported in your area. Exercise caution.`,
                  variant: 'destructive',
                  duration: 8000,
                });
              }
            }
            break;
            
          case 'community_alert':
            // Add new community alert
            setCommunityAlerts(prev => [message.data, ...prev].slice(0, 10)); // Keep last 10 alerts
            toast({
              title: `${message.data.alertType} Alert`,
              description: message.data.message,
              variant: 'destructive',
              duration: 7000,
            });
            break;
            
          default:
            console.log('Unknown message type:', message.type);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    // Connection closed handler
    const handleClose = () => {
      console.log('Disconnected from WebSocket');
      setIsConnected(false);
    };
    
    // Connection error handler
    const handleError = (error: Event) => {
      console.error('WebSocket error:', error);
    };
    
    // Add event listeners
    socket.addEventListener('open', handleOpen);
    socket.addEventListener('message', handleMessage);
    socket.addEventListener('close', handleClose);
    socket.addEventListener('error', handleError);
    
    // Cleanup
    return () => {
      console.log('Closing WebSocket connection');
      socket.removeEventListener('open', handleOpen);
      socket.removeEventListener('message', handleMessage);
      socket.removeEventListener('close', handleClose);
      socket.removeEventListener('error', handleError);
      
      if (socket instanceof WebSocket) {
        socket.close();
      }
    };
  }, [toast]);
  
  // Set up location tracking when connected
  useEffect(() => {
    // Only start tracking if WebSocket is connected and we're on a mobile device
    if (isConnected && navigator.geolocation) {
      // Start tracking location updates
      const setupLocationTracking = () => {
        // If already watching location, clear it first
        if (locationWatchId.current !== null) {
          navigator.geolocation.clearWatch(locationWatchId.current);
        }
        
        // Watch position with high accuracy
        const watchId = navigator.geolocation.watchPosition(
          (position) => {
            // Send location update to server
            sendLocationUpdate(position.coords.latitude, position.coords.longitude);
            
            console.log('Location update sent', {
              lat: position.coords.latitude.toFixed(6),
              lng: position.coords.longitude.toFixed(6)
            });
          },
          (error) => {
            console.error('Error tracking location:', error);
            
            // On mobile, show permission error toast
            if (isMobile && error.code === error.PERMISSION_DENIED) {
              toast({
                title: 'Location Access Needed',
                description: 'Please enable location access for real-time safety alerts',
                duration: 5000,
              });
            }
          },
          {
            enableHighAccuracy: true,
            maximumAge: 10000,      // Accept positions that are up to 10 seconds old
            timeout: 10000          // Wait up to 10 seconds for a position
          }
        );
        
        locationWatchId.current = watchId;
        return watchId;
      };
      
      // Start tracking
      const watchId = setupLocationTracking();
      
      // Cleanup function
      return () => {
        if (watchId) {
          navigator.geolocation.clearWatch(watchId);
        }
      };
    }
    
    return () => {
      // Clear any existing watch
      if (locationWatchId.current !== null && navigator.geolocation) {
        navigator.geolocation.clearWatch(locationWatchId.current);
        locationWatchId.current = null;
      }
    };
  }, [isConnected, isMobile, sendLocationUpdate, toast]);
  
  return {
    isConnected,
    sendLocationUpdate,
    sendEmergencyAlert,
    lastSafetyUpdate,
    nearbyEmergencyServices,
    nearbyCrimeIncidents,
    communityAlerts
  };
};