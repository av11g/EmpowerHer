import React, { createContext, useState, useContext, useEffect, useRef } from 'react';
import { googleMapsApiKey } from '@/lib/google-maps-config';

// Define the map provider types
export type MapProvider = 'google' | 'mapbox';

// Context type definition
interface MapProviderContextType {
  currentProvider: MapProvider;
  setProvider: (provider: MapProvider) => void;
  googleMapRef: React.MutableRefObject<google.maps.Map | null>;
  mapboxMapRef: React.MutableRefObject<mapboxgl.Map | null>;
  isGoogleMapsAvailable: boolean;
  isMapboxAvailable: boolean;
}

// Create context
const MapProviderContext = createContext<MapProviderContextType | undefined>(undefined);

export const MapProviderProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Map references
  const googleMapRef = useRef<google.maps.Map | null>(null);
  const mapboxMapRef = useRef<mapboxgl.Map | null>(null);
  
  // State for provider and availability
  const [currentProvider, setCurrentProvider] = useState<MapProvider>('mapbox'); // Default to Mapbox
  const [isGoogleMapsAvailable, setIsGoogleMapsAvailable] = useState<boolean>(false);
  const [isMapboxAvailable, setIsMapboxAvailable] = useState<boolean>(true);
  
  // Check map providers availability
  useEffect(() => {
    // As per user request, use Mapbox as the primary mapping service
    console.log('Using Mapbox as the primary mapping service');
    setIsMapboxAvailable(true);
    setCurrentProvider('mapbox');
    
    // Mark Google Maps as unavailable due to billing issues
    setIsGoogleMapsAvailable(false);
  }, []);
  
  // Handle provider changes
  const setProvider = (provider: MapProvider) => {
    if (provider === 'google' && !isGoogleMapsAvailable) {
      console.warn('Cannot switch to Google Maps as it is not available');
      return;
    }
    
    if (provider === 'mapbox' && !isMapboxAvailable) {
      console.warn('Cannot switch to Mapbox as it is not available');
      return;
    }
    
    setCurrentProvider(provider);
  };
  
  return (
    <MapProviderContext.Provider
      value={{
        currentProvider,
        setProvider,
        googleMapRef,
        mapboxMapRef,
        isGoogleMapsAvailable,
        isMapboxAvailable
      }}
    >
      {children}
    </MapProviderContext.Provider>
  );
};

// Custom hook to use the map provider context
export const useMapProvider = (): MapProviderContextType => {
  const context = useContext(MapProviderContext);
  if (!context) {
    throw new Error('useMapProvider must be used within a MapProviderProvider');
  }
  return context;
};

// Add the global type for the callback
declare global {
  interface Window {
    testGoogleMapsCallback?: () => void;
  }
}