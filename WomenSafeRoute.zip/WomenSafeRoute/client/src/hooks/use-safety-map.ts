import { useState, useEffect, useCallback, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { 
  ServiceLocation, 
  Route,
  SafetyScore,
  RouteGeoJSON,
  ServiceGeoJSON,
  RouteProperties,
  ServiceProperties 
} from '@shared/schema';

type MapRef = React.MutableRefObject<google.maps.Map | null>;

type SafetyMapHookReturn = {
  mapRef: MapRef;
  routes: Route[];
  isLoadingRoutes: boolean;
  serviceLocations: ServiceLocation[];
  isLoadingServices: boolean;
  safetyScores: SafetyScore[];
  isLoadingSafetyScores: boolean;
  selectedRoute: Route | null;
  selectRoute: (route: Route) => void;
  visibleServiceTypes: Set<string>;
  toggleServiceType: (type: string) => void;
  isSidebarOpen: boolean;
  toggleSidebar: () => void;
  isBottomSheetOpen: boolean;
  toggleBottomSheet: () => void;
  routeGeoJSON: RouteGeoJSON[];
  serviceGeoJSON: ServiceGeoJSON[];
  searchForRoute: (source: string, destination: string) => Route[] | null;
  centerMapOnCoordinates: (latitude: number, longitude: number, zoom?: number) => void;
};

export const useSafetyMap = (): SafetyMapHookReturn => {
  const mapRef = useRef<google.maps.Map | null>(null);
  const [selectedRoute, setSelectedRoute] = useState<Route | null>(null);
  const [visibleServiceTypes, setVisibleServiceTypes] = useState<Set<string>>(
    new Set(['police', 'hospital', 'restaurant'])
  );
  const [isSidebarOpen, setIsSidebarOpen] = useState(true); // Default to open so users can search routes
  const [isBottomSheetOpen, setIsBottomSheetOpen] = useState(true);

  // Fetch routes data
  const { 
    data: routes = [] as Route[], 
    isLoading: isLoadingRoutes
  } = useQuery<Route[]>({
    queryKey: ['/api/routes'],
  });

  // Fetch service locations
  const { 
    data: serviceLocations = [] as ServiceLocation[], 
    isLoading: isLoadingServices
  } = useQuery<ServiceLocation[]>({
    queryKey: ['/api/service-locations'],
  });

  // Fetch safety scores
  const { 
    data: safetyScores = [] as SafetyScore[], 
    isLoading: isLoadingSafetyScores
  } = useQuery<SafetyScore[]>({
    queryKey: ['/api/safety-scores'],
  });

  // Set default selected route when data is loaded
  useEffect(() => {
    if (routes.length > 0 && !selectedRoute) {
      setSelectedRoute(routes[0]); // Default to first route
    }
  }, [routes, selectedRoute]);

  // Convert Route objects to GeoJSON for map display
  const routeGeoJSON: RouteGeoJSON[] = routes.map((route: Route) => {
    // Handle case where route coordinates might be stored as a string
    let coordinates;
    try {
      if (typeof route.coordinates === 'string') {
        // Parse the JSON string to get coordinates array
        coordinates = JSON.parse(route.coordinates);
        
        // Ensure the coordinates are in the correct format [longitude, latitude]
        // Mapbox requires coordinates as [longitude, latitude]
        if (Array.isArray(coordinates) && coordinates.length > 0) {
          // Make sure each coordinate pair is correctly formatted
          coordinates = coordinates.map((coord: any) => {
            // If it's already an array with longitude and latitude, return it
            if (Array.isArray(coord) && coord.length === 2) {
              return coord;
            }
            // If it's an object with lat/lng properties, convert it
            if (coord && typeof coord === 'object' && 'lat' in coord && 'lng' in coord) {
              return [Number(coord.lng), Number(coord.lat)];
            }
            return coord;
          });
        }
      } else {
        coordinates = route.coordinates;
      }
    } catch (error) {
      console.error('Error parsing route coordinates:', error, route.coordinates);
      coordinates = []; // Fallback to empty coordinates
    }
    
    // Debug the coordinates
    console.log(`Route ${route.id} coordinates:`, coordinates);
    
    return {
      type: "Feature",
      geometry: {
        type: "LineString",
        coordinates
      },
      properties: {
        name: route.name,
        safety_level: route.safety_level as "safe" | "moderate" | "danger",
        distance: route.distance,
        duration: route.duration,
        safety_score: route.safety_score,
        lighting: route.lighting,
        foot_traffic: route.foot_traffic
      }
    };
  });

  // Convert ServiceLocation objects to GeoJSON for map display
  const serviceGeoJSON: ServiceGeoJSON[] = serviceLocations.map((location: ServiceLocation) => {
    const properties: ServiceProperties = {
      name: location.name,
      type: location.type as "police" | "hospital" | "restaurant"
    };
    
    // Add optional properties only if they exist
    if (location.description) properties.description = location.description;
    if (location.address) properties.address = location.address;
    if (location.contact) properties.contact = location.contact;
    if (location.operating_hours) properties.operating_hours = location.operating_hours;
    
    return {
      type: "Feature",
      geometry: {
        type: "Point",
        coordinates: [location.longitude, location.latitude]
      },
      properties
    } as ServiceGeoJSON;
  });

  // Function to select a route
  const selectRoute = useCallback((route: Route) => {
    setSelectedRoute(route);
    
    // If we have coordinates and a map reference, center the map on the route
    try {
      const coordinates = typeof route.coordinates === 'string' 
        ? JSON.parse(route.coordinates) 
        : route.coordinates;
        
      if (coordinates && coordinates.length > 0 && mapRef.current) {
        // Get the middle point of the route to center the map
        const midIndex = Math.floor(coordinates.length / 2);
        const midPoint = coordinates[midIndex];
        
        // Center map on the middle point of the route
        if (midPoint && midPoint.length >= 2) {
          const [lng, lat] = midPoint;
          mapRef.current.panTo({ lat, lng });
          mapRef.current.setZoom(15);
        }
      }
    } catch (error) {
      console.error('Error handling route selection:', error);
    }
  }, []);

  // Function to search for routes between source and destination
  const searchForRoute = useCallback((source: string, destination: string): Route[] | null => {
    if (!routes || routes.length === 0) return null;
    
    // Extract just the location name without 'Thoothukudi'
    const sourceText = source.toLowerCase().replace('thoothukudi', '').trim();
    const destinationText = destination.toLowerCase().replace('thoothukudi', '').trim();
    
    // First try direct match
    let matchingRoutes = routes.filter(route => {
      const routeName = route.name.toLowerCase();
      
      // Check if route name contains both source and destination
      const hasSource = routeName.includes(sourceText);
      const hasDestination = routeName.includes(destinationText);
      
      // Check the pattern "Source to Destination" or "Source - Destination"
      const directRouteMatch = 
        (hasSource && hasDestination) && 
        (routeName.indexOf(sourceText) < routeName.indexOf(destinationText));
      
      // Check for reversed route "Destination to Source"
      const reversedRouteMatch = 
        (hasSource && hasDestination) && 
        (routeName.indexOf(destinationText) < routeName.indexOf(sourceText));
      
      return directRouteMatch || reversedRouteMatch;
    });
    
    // If no direct matches, fall back to more flexible matching
    if (matchingRoutes.length === 0) {
      matchingRoutes = routes.filter(route => {
        const routeName = route.name.toLowerCase();
        
        // Check if both source and destination keywords are in the route name
        const hasSourceKeyword = sourceText.split(' ').some(word => 
          word.length > 2 && routeName.includes(word)
        );
        
        const hasDestinationKeyword = destinationText.split(' ').some(word => 
          word.length > 2 && routeName.includes(word)
        );
        
        return hasSourceKeyword && hasDestinationKeyword;
      });
      
      // If still no matches, just return any routes that might be relevant
      if (matchingRoutes.length === 0) {
        matchingRoutes = routes.filter(route => {
          const routeName = route.name.toLowerCase();
          
          // Match if either source or destination is in the name
          return routeName.includes(sourceText) || routeName.includes(destinationText);
        });
      }
    }
    
    // For demo purposes, if there are still no routes, return some routes so users can see visualization
    if (matchingRoutes.length === 0 && routes.length > 0) {
      // Return the first few routes as a fallback for demo
      matchingRoutes = routes.slice(0, 3);
    }
    
    return matchingRoutes.length > 0 ? matchingRoutes : null;
  }, [routes]);

  // Function to center map on specific coordinates
  const centerMapOnCoordinates = useCallback((latitude: number, longitude: number, zoom = 16) => {
    if (mapRef.current) {
      mapRef.current.panTo({ lat: latitude, lng: longitude });
      mapRef.current.setZoom(zoom);
    }
  }, []);

  // Toggle service type visibility
  const toggleServiceType = useCallback((type: string) => {
    setVisibleServiceTypes(prev => {
      const newSet = new Set(prev);
      if (newSet.has(type)) {
        newSet.delete(type);
      } else {
        newSet.add(type);
      }
      return newSet;
    });
  }, []);

  // Toggle sidebar visibility
  const toggleSidebar = useCallback(() => {
    setIsSidebarOpen(prev => !prev);
  }, []);

  // Toggle bottom sheet visibility
  const toggleBottomSheet = useCallback(() => {
    setIsBottomSheetOpen(prev => !prev);
  }, []);

  return {
    mapRef,
    routes,
    isLoadingRoutes,
    serviceLocations,
    isLoadingServices,
    safetyScores,
    isLoadingSafetyScores,
    selectedRoute,
    selectRoute,
    visibleServiceTypes,
    toggleServiceType,
    isSidebarOpen,
    toggleSidebar,
    isBottomSheetOpen,
    toggleBottomSheet,
    routeGeoJSON,
    serviceGeoJSON,
    searchForRoute,
    centerMapOnCoordinates
  };
};
