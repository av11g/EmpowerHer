// Convert safety levels to colors
export const getSafetyLevelColor = (level: string): string => {
  switch (level) {
    case 'safe':
      return '#4CAF50'; // Green
    case 'moderate':
      return '#FFC107'; // Amber
    case 'danger':
      return '#F44336'; // Red
    default:
      return '#757575'; // Grey
  }
};

// Get safety level based on score
export const getSafetyLevelFromScore = (score: number): 'safe' | 'moderate' | 'danger' => {
  if (score >= 75) return 'safe';
  if (score >= 50) return 'moderate';
  return 'danger';
};

// Get service type color
export const getServiceTypeColor = (type: string): string => {
  switch (type) {
    case 'police':
      return '#2196F3'; // Blue
    case 'hospital':
      return '#F44336'; // Red
    case 'restaurant':
      return '#FF9800'; // Orange
    default:
      return '#757575'; // Grey
  }
};

// Get service type icon
export const getServiceTypeIcon = (type: string): string => {
  switch (type) {
    case 'police':
      return 'local_police';
    case 'hospital':
      return 'local_hospital';
    case 'restaurant':
      return 'restaurant';
    default:
      return 'place';
  }
};

// Get lighting description icon
export const getLightingIcon = (lighting: string): string => {
  switch (lighting) {
    case 'well-lit':
      return 'visibility';
    case 'partially lit':
      return 'visibility';
    case 'poor lighting':
      return 'visibility_off';
    default:
      return 'visibility';
  }
};

// Get foot traffic icon
export const getFootTrafficIcon = (footTraffic: string): string => {
  switch (footTraffic) {
    case 'high':
      return 'people';
    case 'moderate':
      return 'people';
    case 'low':
      return 'people_outline';
    default:
      return 'people';
  }
};

// Calculate width percentage for safety score bar
export const getSafetyScoreWidth = (score: number): string => {
  return `${score}%`;
};
