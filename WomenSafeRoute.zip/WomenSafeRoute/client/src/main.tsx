import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add Mapbox token from environment variables
// This should be provided through the hosting environment
if (!import.meta.env.VITE_MAPBOX_TOKEN) {
  console.warn("Mapbox token not found in environment variables. Map functionality will be limited.");
}

createRoot(document.getElementById("root")!).render(<App />);
