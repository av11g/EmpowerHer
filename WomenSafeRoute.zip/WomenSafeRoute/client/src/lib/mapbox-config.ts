import mapboxgl from 'mapbox-gl';

declare global {
  interface Window {
    REPLIT_ENVIRONMENT?: {
      GOOGLE_MAPS_API_KEY?: string;
      MAPBOX_TOKEN?: string;
    }
  }
}

let mapboxTokenSet = false;

async function fetchMapboxToken() {
  try {
    const response = await fetch('/api/config');
    if (response.ok) {
      const config = await response.json();
      if (config.mapbox && config.mapbox.accessToken) {
        mapboxgl.accessToken = config.mapbox.accessToken;
        mapboxTokenSet = true;
        return true;
      }
    }
    return false;
  } catch (error) {
    console.error('Error fetching Mapbox token:', error);
    return false;
  }
}

const initMapboxToken = async () => {
  // First try server API
  const apiSuccess = await fetchMapboxToken();
  if (apiSuccess) return true;

  // Try Vite env
  if (import.meta.env.VITE_MAPBOX_TOKEN) {
    mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN;
    mapboxTokenSet = true;
    return true;
  }

  // Try Replit env
  if (window.REPLIT_ENVIRONMENT?.MAPBOX_TOKEN) {
    mapboxgl.accessToken = window.REPLIT_ENVIRONMENT.MAPBOX_TOKEN;
    mapboxTokenSet = true;
    return true;
  }

  console.error('No Mapbox token found');
  return false;
};

export { mapboxgl, mapboxTokenSet, initMapboxToken };