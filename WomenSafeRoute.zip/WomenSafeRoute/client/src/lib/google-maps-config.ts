// Configuration for Google Maps API
declare global {
  interface Window {
    REPLIT_ENVIRONMENT?: {
      GOOGLE_MAPS_API_KEY?: string;
      MAPBOX_TOKEN?: string;
    };
  }
}

// Default API key - will be replaced if a valid one is found
export let googleMapsApiKey = '';

// Fetch configuration from server API
async function fetchGoogleMapsApiKey(): Promise<string> {
  try {
    const response = await fetch('/api/config');
    if (response.ok) {
      const config = await response.json();
      if (config.googleMaps && config.googleMaps.apiKey) {
        console.log('Using Google Maps API key from server config API');
        return config.googleMaps.apiKey;
      }
    }
  } catch (error) {
    console.error('Error fetching Google Maps API key:', error);
  }
  
  // For client-side in Vite, check specific environment access patterns
  if (import.meta.env.VITE_GOOGLE_MAPS_API_KEY) {
    console.log('Found API key in import.meta.env.VITE_GOOGLE_MAPS_API_KEY');
    return import.meta.env.VITE_GOOGLE_MAPS_API_KEY;
  }
  
  // Try from window.REPLIT_ENVIRONMENT (most likely source in Replit)
  if (typeof window !== 'undefined' && 
      window.REPLIT_ENVIRONMENT && 
      window.REPLIT_ENVIRONMENT.GOOGLE_MAPS_API_KEY) {
    console.log('Found API key in window.REPLIT_ENVIRONMENT.GOOGLE_MAPS_API_KEY');
    return window.REPLIT_ENVIRONMENT.GOOGLE_MAPS_API_KEY;
  }
  
  // Return empty string to indicate no valid key was found
  console.log('Using fallback Google Maps API key - check environment variables');
  return "";
};

// Attempt to set the API key
fetchGoogleMapsApiKey().then(key => {
  googleMapsApiKey = key;
});

// Default center coordinates for Thoothukudi, India
export const defaultCenter = {
  lat: 8.7638,
  lng: 78.1348
};

// Map configuration options
export const mapContainerStyle = {
  width: '100%',
  height: '100vh'
};

export const defaultZoom = 14;

// Map styling options for a safety-focused map
export const mapOptions = {
  disableDefaultUI: false,
  zoomControl: true,
  mapTypeControl: false,
  streetViewControl: false,
  fullscreenControl: false,
  rotateControl: false,
  scaleControl: true,
  styles: [
    {
      // Emphasize road network for safety navigation
      featureType: 'road',
      elementType: 'geometry',
      stylers: [
        { color: '#ffffff' },
        { weight: 1.5 }
      ]
    },
    {
      // Add subtle highlighting to main roads
      featureType: 'road.highway',
      elementType: 'geometry',
      stylers: [
        { color: '#f7f7f7' },
        { weight: 2.0 }
      ]
    },
    {
      // Make road labels more visible
      featureType: 'road',
      elementType: 'labels.text',
      stylers: [
        { color: '#5f5f5f' },
        { weight: 1.0 },
        { visibility: 'on' }
      ]
    },
    {
      // Enhance point of interest visibility for safety landmarks
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'on' }]
    },
    {
      // Emphasize transit options 
      featureType: 'transit',
      elementType: 'labels',
      stylers: [{ visibility: 'on' }]
    },
    {
      // Tone down less important features
      featureType: 'administrative',
      elementType: 'geometry',
      stylers: [{ color: '#e9e9e9' }]
    },
    {
      // Make water features stand out as landmarks
      featureType: 'water',
      elementType: 'geometry',
      stylers: [{ color: '#c1e0f0' }]
    },
    {
      // Instead of 'building' (which causes errors), use poi.business for similar effect
      featureType: 'poi.business',
      elementType: 'geometry',
      stylers: [{ color: '#f0f0f0' }]
    },
    {
      // Instead of 'park' (which causes errors), use poi.park for safe zones
      featureType: 'poi.park',
      elementType: 'geometry',
      stylers: [{ color: '#d8f0ce' }]
    }
  ]
};