import React, { useRef, useState, useEffect } from 'react';
import mapboxgl from 'mapbox-gl';
import { mapboxTokenSet } from '@/lib/mapbox-config';
import { useWebSocket } from '@/hooks/use-websocket';
import { useSafetyMap } from '@/hooks/use-safety-map';
import { AlertTriangle, Navigation, X, ZoomIn, ZoomOut, Compass } from 'lucide-react';
import { getSafetyLevelColor } from '@/utils/color-utils';
import 'mapbox-gl/dist/mapbox-gl.css';
import RouteSearch from './RouteSearch';
import RouteInfo from './RouteInfo';

interface SimpleMapboxContainerProps {
  mapRef: React.MutableRefObject<mapboxgl.Map | null>;
}

const SimpleMapboxContainer: React.FC<SimpleMapboxContainerProps> = ({ mapRef }) => {
  const { sendLocationUpdate } = useWebSocket();
  const { routes, selectedRoute, routeGeoJSON, selectRoute } = useSafetyMap();
  
  const [mapError, setMapError] = useState<string | null>(null);
  const [userPosition, setUserPosition] = useState<{ lat: number; lng: number }>({ lat: 8.7638, lng: 78.1348 }); // Thoothukudi center
  
  const mapContainerRef = useRef<HTMLDivElement>(null);
  
  // Handle Mapbox errors
  const handleMapboxError = (error: any) => {
    console.error('Mapbox error:', error);
    
    // Common Mapbox error messages and user-friendly alternatives
    const errorMessages: {[key: string]: string} = {
      'InvalidAccessToken': 'Invalid Mapbox access token. Please check your configuration.',
      'TokenMissing': 'Mapbox access token is missing. Please check your configuration.',
      'RequestTimeout': 'Mapbox request timed out. Please check your internet connection.',
      'Connection Error': 'Could not connect to Mapbox servers. Please check your internet connection.',
      'TileErrorUnknown': 'Error loading map tiles. Please try refreshing the page.',
      'ExpiredToken': 'Your Mapbox token has expired. Please update your token.',
      'StyleNotFound': 'The requested map style was not found. Please try a different style.',
      'SourceNotFound': 'The requested map source was not found.',
      'LayerNotFound': 'The requested map layer was not found.',
    };
    
    // Get a user-friendly error message
    let userMessage = 'There was an error loading the map.';
    
    if (error) {
      const errorString = error.toString();
      for (const [key, message] of Object.entries(errorMessages)) {
        if (errorString.includes(key)) {
          userMessage = message;
          break;
        }
      }
    }
    
    setMapError(userMessage);
  };

  // Initialize map
  useEffect(() => {
    const mapContainer = mapContainerRef.current;
    if (!mapContainer) return;
    
    const initMap = async () => {
      try {
        console.log('Initializing Mapbox map...');
        
        // Check if we already have a token
        if (!mapboxgl.accessToken) {
          console.log('No Mapbox token found, fetching from server');
          // Always get the Mapbox token directly from server
          const response = await fetch('/api/config');
          if (!response.ok) {
            throw new Error('Failed to fetch map configuration');
          }
          
          const config = await response.json();
          console.log('Mapbox config response:', config);
          
          if (!config.mapbox || !config.mapbox.accessToken) {
            throw new Error('No valid Mapbox token found in server response');
          }
          
          // Set the Mapbox token
          console.log('Setting Mapbox token directly from API');
          mapboxgl.accessToken = config.mapbox.accessToken;
          
          if (!mapboxgl.accessToken) {
            throw new Error('Mapbox token still not set after API call');
          }
        }
        
        console.log('Mapbox token set:', mapboxgl.accessToken ? 'Yes' : 'No', 'Token:', mapboxgl.accessToken);
        
        // Create map
        const map = new mapboxgl.Map({
          container: mapContainer,
          style: 'mapbox://styles/mapbox/streets-v12',
          center: [userPosition.lng, userPosition.lat],
          zoom: 14
        });
        
        mapRef.current = map;
        
        // Add navigation controls
        map.addControl(new mapboxgl.NavigationControl(), 'top-right');
        
        // Add base marker for user location
        const userMarker = new mapboxgl.Marker({ color: '#2196F3' })
          .setLngLat([userPosition.lng, userPosition.lat])
          .addTo(map);
          
        // Try to get user's actual location
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              const { latitude, longitude } = position.coords;
              setUserPosition({ lat: latitude, lng: longitude });
              userMarker.setLngLat([longitude, latitude]);
              map.flyTo({ center: [longitude, latitude], zoom: 14 });
              sendLocationUpdate(latitude, longitude);
            },
            (error) => {
              console.log('Geolocation error:', error);
              sendLocationUpdate(userPosition.lat, userPosition.lng);
            }
          );
        }
        // Add error handling for map
        map.on('error', (e) => {
          console.error('Mapbox map error:', e.error);
          handleMapboxError(e.error);
        });
        
        // Wait for map to load
        map.on('load', () => {
          console.log('Mapbox map loaded successfully');
        });
        
      } catch (error) {
        console.error('Map initialization error:', error);
        handleMapboxError(error);
      }
    };
    
    initMap();
    
    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [mapRef, sendLocationUpdate, userPosition.lat, userPosition.lng]);
  
  // Handle route display
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !map.loaded()) return;
    
    const handleRoutes = () => {
      try {
        // Clear existing routes
        const mapStyle = map.getStyle();
        const layerIds = mapStyle && mapStyle.layers ? mapStyle.layers.map(layer => layer.id) : [];
        layerIds.forEach(id => {
          if (id && (id.startsWith('route-') || id.startsWith('route-outline-') || id.startsWith('route-glow-'))) {
            map.removeLayer(id);
          }
        });
        
        // Clear existing sources
        for (let i = 0; i < 200; i++) {
          try {
            if (map.getSource(`route-source-${i}`)) {
              map.removeSource(`route-source-${i}`);
            }
          } catch (e) {
            // Ignore errors for non-existent sources
          }
        }
        
        // Clear existing markers
        document.querySelectorAll('.mapboxgl-marker').forEach(marker => {
          if (marker.classList.contains('route-marker')) {
            marker.remove();
          }
        });
        
        // Add routes to map
        routes.forEach((route, index) => {
          if (!routeGeoJSON[index]) return;
          
          const isSelected = selectedRoute?.id === route.id;
          const safetyLevel = route.safety_level;
          const safetyColor = getSafetyLevelColor(safetyLevel);
          
          let coordinates: [number, number][] = [];
          try {
            // Get coordinates with proper parsing
            if (typeof route.coordinates === 'string') {
              coordinates = JSON.parse(route.coordinates);
              console.log(`Route ${index} (${route.id}) parsed coordinates:`, coordinates);
            } else if (Array.isArray(route.coordinates)) {
              coordinates = route.coordinates;
              console.log(`Route ${index} (${route.id}) array coordinates:`, coordinates);
            } else if (routeGeoJSON[index] && routeGeoJSON[index].geometry) {
              coordinates = routeGeoJSON[index].geometry.coordinates;
              console.log(`Route ${index} (${route.id}) geoJSON coordinates:`, coordinates);
            } else {
              console.error(`Route ${index} (${route.id}) has invalid coordinates:`, route.coordinates);
              return;
            }
              
            // Add source
            map.addSource(`route-source-${index}`, {
              type: 'geojson',
              data: {
                type: 'Feature',
                properties: {
                  name: route.name,
                  safety_level: route.safety_level
                },
                geometry: {
                  type: 'LineString',
                  coordinates: coordinates
                }
              }
            });
            
            // Add route line with simple style based on safety
            map.addLayer({
              id: `route-${index}`,
              type: 'line',
              source: `route-source-${index}`,
              layout: {
                'line-join': 'round',
                'line-cap': 'round'
              },
              paint: {
                'line-color': safetyColor,
                'line-width': isSelected ? 7 : 3,
                'line-opacity': isSelected ? 1 : 0.7,
                // Add dashed line for moderate routes
                'line-dasharray': safetyLevel === 'moderate' ? [2, 1] : 
                                  safetyLevel === 'danger' ? [1, 1] : undefined
              }
            });
            
            // Add click handler
            map.on('click', `route-${index}`, () => {
              selectRoute(route);
            });
            
            // Add hover effect
            map.on('mouseenter', `route-${index}`, () => {
              map.getCanvas().style.cursor = 'pointer';
            });
            
            map.on('mouseleave', `route-${index}`, () => {
              map.getCanvas().style.cursor = '';
            });
            
            // Add start/end markers for selected route
            if (isSelected && coordinates.length >= 2) {
              // Start marker
              const startMarker = document.createElement('div');
              startMarker.className = 'route-marker mapboxgl-marker-start';
              startMarker.style.width = '24px';
              startMarker.style.height = '24px';
              startMarker.style.borderRadius = '50%';
              startMarker.style.backgroundColor = '#4CAF50';
              startMarker.style.border = '2px solid white';
              startMarker.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
              startMarker.style.display = 'flex';
              startMarker.style.alignItems = 'center';
              startMarker.style.justifyContent = 'center';
              startMarker.style.color = 'white';
              startMarker.style.fontWeight = 'bold';
              startMarker.innerText = 'A';
              
              new mapboxgl.Marker(startMarker)
                .setLngLat(coordinates[0])
                .addTo(map);
                
              // End marker
              const endMarker = document.createElement('div');
              endMarker.className = 'route-marker mapboxgl-marker-end';
              endMarker.style.width = '24px';
              endMarker.style.height = '24px';
              endMarker.style.borderRadius = '50%';
              endMarker.style.backgroundColor = '#F44336';
              endMarker.style.border = '2px solid white';
              endMarker.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';
              endMarker.style.display = 'flex';
              endMarker.style.alignItems = 'center';
              endMarker.style.justifyContent = 'center';
              endMarker.style.color = 'white';
              endMarker.style.fontWeight = 'bold';
              endMarker.innerText = 'B';
              
              new mapboxgl.Marker(endMarker)
                .setLngLat(coordinates[coordinates.length - 1])
                .addTo(map);
                
              // Fit map to route bounds
              const bounds = new mapboxgl.LngLatBounds();
              coordinates.forEach((coord: [number, number]) => {
                bounds.extend(coord);
              });
              
              map.fitBounds(bounds, {
                padding: 50,
                duration: 800
              });
            }
          } catch (error) {
            console.error(`Error adding route ${index}:`, error);
          }
        });
      } catch (error) {
        console.error('Error updating routes:', error);
      }
    };
    
    // Handle routes when map is loaded
    if (map.loaded()) {
      handleRoutes();
    } else {
      map.once('load', handleRoutes);
    }
  }, [mapRef, routes, routeGeoJSON, selectedRoute, selectRoute]);
  
  // Show error if map failed to load
  if (mapError) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-gray-100">
        <div className="p-6 bg-white rounded-lg shadow text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-700 mb-2">Map Error</h2>
          <p>{mapError}</p>
          <p className="mt-4 text-gray-500 text-sm">Please refresh the page to try again.</p>
        </div>
      </div>
    );
  }
  
  // Function to handle route selection from the RouteSearch component
  const handleRouteSelection = (routeId: number) => {
    const route = routes.find(r => r.id === routeId);
    if (route) {
      selectRoute(route);
    }
  };

  const [showSearch, setShowSearch] = useState(true);
  const [showRouteInfo, setShowRouteInfo] = useState(false);
  
  // Show route info panel when a route is selected
  useEffect(() => {
    if (selectedRoute) {
      setShowRouteInfo(true);
    }
  }, [selectedRoute]);

  return (
    <div className="w-full h-full relative">
      {/* User guidance note */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10 px-4 py-2 bg-white rounded-lg shadow text-sm text-center">
        <p className="font-medium text-primary">View color-coded safe routes in Thoothukudi</p>
      </div>
      
      {/* Route Search Panel */}
      <div className="absolute top-16 left-4 z-10 w-80 max-w-[80vw]">
        {showSearch ? (
          <div className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="flex justify-end p-2">
              <button 
                onClick={() => setShowSearch(false)}
                className="p-1 rounded-full hover:bg-gray-100"
              >
                <X className="h-4 w-4 text-gray-500" />
              </button>
            </div>
            <RouteSearch onSelectRoute={handleRouteSelection} />
          </div>
        ) : (
          <button
            onClick={() => setShowSearch(true)}
            className="bg-white p-3 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-100"
          >
            <Navigation className="h-5 w-5 text-primary" />
          </button>
        )}
      </div>
      
      {/* Map controls */}
      <div className="absolute bottom-8 right-4 z-10 flex flex-col space-y-2">
        <button
          onClick={() => {
            if (mapRef.current) {
              mapRef.current.zoomIn();
            }
          }}
          className="bg-white p-2 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-100"
        >
          <ZoomIn className="h-5 w-5 text-gray-700" />
        </button>
        <button
          onClick={() => {
            if (mapRef.current) {
              mapRef.current.zoomOut();
            }
          }}
          className="bg-white p-2 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-100"
        >
          <ZoomOut className="h-5 w-5 text-gray-700" />
        </button>
        <button
          onClick={() => {
            if (mapRef.current) {
              // Reset bearing to north (0 degrees)
              mapRef.current.easeTo({
                bearing: 0,
                pitch: 0
              });
            }
          }}
          className="bg-white p-2 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-100"
        >
          <Compass className="h-5 w-5 text-gray-700" />
        </button>
      </div>
      
      {/* Legend */}
      <div className="absolute bottom-8 left-4 z-10 bg-white p-3 rounded-lg shadow-lg">
        <h3 className="font-medium text-sm mb-2">Route Safety</h3>
        <div className="space-y-2">
          <div className="flex items-center">
            <div className="w-4 h-4 bg-green-500 rounded-full mr-2"></div>
            <span className="text-xs">Safe Route</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-yellow-500 rounded-full mr-2"></div>
            <span className="text-xs">Moderate Safety</span>
          </div>
          <div className="flex items-center">
            <div className="w-4 h-4 bg-red-500 rounded-full mr-2"></div>
            <span className="text-xs">Low Safety</span>
          </div>
        </div>
      </div>
      
      {/* Route Info Panel - shows when a route is selected */}
      {selectedRoute && showRouteInfo && (
        <div className="absolute bottom-36 right-4 z-10 w-80 max-w-[80vw]">
          <RouteInfo 
            route={selectedRoute}
            onClose={() => {
              setShowRouteInfo(false);
            }}
            onNavigate={() => {
              // Start navigation
              if (mapRef.current && selectedRoute.coordinates) {
                try {
                  let coords = [];
                  if (typeof selectedRoute.coordinates === 'string') {
                    coords = JSON.parse(selectedRoute.coordinates);
                  } else if (Array.isArray(selectedRoute.coordinates)) {
                    coords = selectedRoute.coordinates;
                  }
                  
                  if (coords.length >= 2) {
                    // Fit map to route bounds
                    const bounds = new mapboxgl.LngLatBounds();
                    coords.forEach((coord: [number, number]) => {
                      bounds.extend(coord);
                    });
                    
                    mapRef.current.fitBounds(bounds, {
                      padding: 50,
                      duration: 800
                    });
                  }
                } catch (e) {
                  console.error('Error navigating route:', e);
                }
              }
            }}
          />
        </div>
      )}
      
      {/* Map container */}
      <div 
        ref={mapContainerRef} 
        style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
      />
    </div>
  );
};

export default SimpleMapboxContainer;