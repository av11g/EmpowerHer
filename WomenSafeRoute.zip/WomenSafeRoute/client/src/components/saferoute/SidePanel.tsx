import React, { useState } from 'react';
import { useSafetyMap } from '@/hooks/use-safety-map';
import RouteSearchPanel from '@/components/saferoute/RouteSearchPanel';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ChevronLeft, ChevronRight, User, Home, Map, 
  History, Users, Settings, HelpCircle, Search, 
  MapPin, Shield, AlertTriangle, Check, CheckSquare
} from 'lucide-react';

interface SidePanelProps {
  isOpen: boolean;
  toggleSidebar: () => void;
}

// Define checkpoint types
type Checkpoint = {
  id: number;
  name: string;
  location: string;
  status: 'verified' | 'pending' | 'warning';
  lastChecked: string;
  latitude: number;
  longitude: number;
};

// Sample checkpoints data for Thoothukudi
const thoothukudiCheckpoints: Checkpoint[] = [
  {
    id: 1,
    name: "Thoothukudi Bus Stand",
    location: "Central Thoothukudi",
    status: 'verified',
    lastChecked: "2 hours ago",
    latitude: 8.7638,
    longitude: 78.1348
  },
  {
    id: 2,
    name: "VOC College Junction",
    location: "Near Beach Road",
    status: 'verified',
    lastChecked: "1 hour ago",
    latitude: 8.7642,
    longitude: 78.1328
  },
  {
    id: 3,
    name: "Third Mile Bridge",
    location: "Third Mile Area",
    status: 'warning',
    lastChecked: "3 hours ago",
    latitude: 8.7712,
    longitude: 78.1343
  },
  {
    id: 4,
    name: "VVD Signal",
    location: "Central Thoothukudi",
    status: 'verified',
    lastChecked: "30 minutes ago",
    latitude: 8.7599,
    longitude: 78.1354
  },
  {
    id: 5,
    name: "Millerpuram Check Post",
    location: "Millerpuram Area",
    status: 'pending',
    lastChecked: "5 hours ago",
    latitude: 8.7541,
    longitude: 78.1368
  },
  {
    id: 6,
    name: "Harbor Beach Entry",
    location: "Beach Road",
    status: 'verified',
    lastChecked: "1 hour ago",
    latitude: 8.7658,
    longitude: 78.1158
  },
  {
    id: 7,
    name: "Railway Station Junction",
    location: "Station Area",
    status: 'verified',
    lastChecked: "4 hours ago",
    latitude: 8.7661,
    longitude: 78.1292
  }
];

const SidePanel: React.FC<SidePanelProps> = ({ isOpen, toggleSidebar }) => {
  const {
    routes,
    isLoadingRoutes,
    selectedRoute,
    selectRoute,
    mapRef
  } = useSafetyMap();
  
  const [activeTab, setActiveTab] = useState<'routes' | 'checkpoints' | 'info'>('routes');
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredCheckpoints, setFilteredCheckpoints] = useState<Checkpoint[]>(thoothukudiCheckpoints);
  
  // Handle location search
  const handleSearch = () => {
    if (!searchTerm.trim()) {
      setFilteredCheckpoints(thoothukudiCheckpoints);
      return;
    }
    
    const lowerSearch = searchTerm.toLowerCase();
    const filtered = thoothukudiCheckpoints.filter(
      checkpoint => 
        checkpoint.name.toLowerCase().includes(lowerSearch) ||
        checkpoint.location.toLowerCase().includes(lowerSearch)
    );
    
    setFilteredCheckpoints(filtered);
  };
  
  // Handle checkpoint click - center map on checkpoint location
  const handleCheckpointClick = (checkpoint: Checkpoint) => {
    if (mapRef.current) {
      mapRef.current.panTo({ lat: checkpoint.latitude, lng: checkpoint.longitude });
      mapRef.current.setZoom(16); // Zoom in closer
    }
  };
  
  return (
    <div 
      className={`h-full z-20 bg-white shadow-lg border-r overflow-auto transition-all duration-300 ${
        isOpen ? 'w-80' : 'w-0'
      }`}
    >
      {/* Handle to collapse/expand sidebar */}
      <div 
        className="absolute top-4 -right-10 bg-white p-2 rounded-full shadow-md cursor-pointer"
        onClick={toggleSidebar}
      >
        {isOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
      </div>
      
      {/* User Profile */}
      <div className="bg-primary p-4 text-white">
        <div className="flex items-center">
          <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center text-primary">
            <User className="h-6 w-6" />
          </div>
          <div className="ml-3">
            <h2 className="font-semibold">User Profile</h2>
            <p className="text-xs opacity-80">Thoothukudi Safety Map</p>
          </div>
        </div>
      </div>
      
      {/* Simple tab navigation without the Radix component */}
      <div className="w-full">
        <div className="flex border-b">
          <button 
            className={`flex-1 py-2 px-4 font-medium text-sm ${activeTab === 'routes' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
            onClick={() => setActiveTab('routes')}
          >
            Routes
          </button>
          <button 
            className={`flex-1 py-2 px-4 font-medium text-sm ${activeTab === 'checkpoints' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
            onClick={() => setActiveTab('checkpoints')}
          >
            Checkpoints
          </button>
          <button 
            className={`flex-1 py-2 px-4 font-medium text-sm ${activeTab === 'info' ? 'text-primary border-b-2 border-primary' : 'text-gray-500'}`}
            onClick={() => setActiveTab('info')}
          >
            Safety Info
          </button>
        </div>

        {/* Routes Tab Content */}
        {activeTab === 'routes' && (
          <div className="p-3">
            <RouteSearchPanel 
              routes={routes}
              selectedRoute={selectedRoute}
              selectRoute={selectRoute}
              isLoading={isLoadingRoutes}
            />
          </div>
        )}
        
        {/* Checkpoints Tab Content */}
        {activeTab === 'checkpoints' && (
          <div className="p-3">
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Thoothukudi Checkpoints</h3>
              
              {/* Search box for checkpoints */}
              <div className="flex space-x-2">
                <Input 
                  placeholder="Search locations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
                <Button size="sm" onClick={handleSearch}>
                  <Search className="h-4 w-4" />
                </Button>
              </div>
              
              {/* Checkpoints list */}
              <div className="space-y-3 max-h-[calc(100vh-360px)] overflow-y-auto pr-1">
                {filteredCheckpoints.length > 0 ? (
                  filteredCheckpoints.map(checkpoint => (
                    <div 
                      key={checkpoint.id}
                      className="bg-white border rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => handleCheckpointClick(checkpoint)}
                    >
                      <div className="flex justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm flex items-center">
                            <MapPin className="h-4 w-4 mr-1 text-primary" />
                            {checkpoint.name}
                          </h4>
                          <p className="text-xs text-gray-500 mt-1">{checkpoint.location}</p>
                        </div>
                        
                        {/* Status indicator */}
                        <div className="flex items-start">
                          {checkpoint.status === 'verified' && (
                            <div className="bg-green-100 p-1 rounded-full">
                              <CheckSquare className="h-4 w-4 text-green-600" />
                            </div>
                          )}
                          {checkpoint.status === 'warning' && (
                            <div className="bg-orange-100 p-1 rounded-full">
                              <AlertTriangle className="h-4 w-4 text-orange-600" />
                            </div>
                          )}
                          {checkpoint.status === 'pending' && (
                            <div className="bg-blue-100 p-1 rounded-full">
                              <Shield className="h-4 w-4 text-blue-600" />
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Last checked time */}
                      <div className="flex items-center mt-2">
                        <span className="text-xs text-gray-500">Last checked: {checkpoint.lastChecked}</span>
                      </div>
                      
                      {/* Safety status description */}
                      <div className="mt-2 text-xs">
                        {checkpoint.status === 'verified' && (
                          <span className="text-green-600 flex items-center">
                            <Check className="h-3 w-3 mr-1" />
                            Safe passage verified
                          </span>
                        )}
                        {checkpoint.status === 'warning' && (
                          <span className="text-orange-600 flex items-center">
                            <AlertTriangle className="h-3 w-3 mr-1" />
                            Exercise caution in this area
                          </span>
                        )}
                        {checkpoint.status === 'pending' && (
                          <span className="text-blue-600 flex items-center">
                            <Shield className="h-3 w-3 mr-1" />
                            Awaiting latest safety update
                          </span>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-6">
                    <SearchIcon className="h-12 w-12 text-gray-300 mx-auto" />
                    <h3 className="mt-2 text-gray-500">No checkpoints found</h3>
                    <p className="text-sm text-gray-400">Try a different search term</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        
        {/* Safety Info Tab Content */}
        {activeTab === 'info' && (
          <>
            {/* Safety Tips */}
            <div className="px-4 py-3 bg-white">
              <h3 className="font-medium text-sm uppercase text-gray-500">Thoothukudi Safety Tips</h3>
              <div className="mt-2 space-y-3">
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-600">
                    <span className="text-xs mr-1 text-primary">✓</span>
                    Tamil Nadu Women Helpline: 1091
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-600">
                    <span className="text-xs mr-1 text-primary">✓</span>
                    Download "Kavalan SOS" app by Tamil Nadu Police for emergencies
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-600">
                    <span className="text-xs mr-1 text-primary">✓</span>
                    Prefer traveling in well-lit areas around VOC Port and Bus Stand after dark
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-600">
                    <span className="text-xs mr-1 text-primary">✓</span>
                    Keep emergency contacts saved - Thoothukudi Police Control: 100
                  </p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <p className="text-sm text-gray-600">
                    <span className="text-xs mr-1 text-primary">✓</span>
                    Use designated auto stands near VVD Signal and Bus Stand
                  </p>
                </div>
              </div>
            </div>
            
            {/* Emergency Contacts */}
            <div className="px-4 py-3 border-t">
              <h3 className="font-medium text-sm uppercase text-gray-500">Emergency Contacts</h3>
              <div className="mt-2 space-y-2">
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                    </svg>
                  </div>
                  <div className="ml-2">
                    <p className="text-sm font-medium">Thoothukudi Police</p>
                    <p className="text-xs text-gray-500">0461-2340180</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center text-green-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M19 4v16h-12a2 2 0 0 1-2-2v-12a2 2 0 0 1 2-2h12zM9 4v16" />
                      <path d="M12 8h2" />
                      <path d="M12 12h2" />
                      <path d="M12 16h2" />
                    </svg>
                  </div>
                  <div className="ml-2">
                    <p className="text-sm font-medium">Govt Medical College</p>
                    <p className="text-xs text-gray-500">0461-2328031</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center text-purple-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                      <circle cx="9" cy="7" r="4" />
                      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                    </svg>
                  </div>
                  <div className="ml-2">
                    <p className="text-sm font-medium">Women Helpline</p>
                    <p className="text-xs text-gray-500">1091</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-500">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M4.5 9.5V5.5C4.5 4.4 5.4 3.5 6.5 3.5H17.5C18.6 3.5 19.5 4.4 19.5 5.5V9.5" />
                      <path d="M4.5 14.5V18.5C4.5 19.6 5.4 20.5 6.5 20.5H17.5C18.6 20.5 19.5 19.6 19.5 18.5V14.5" />
                      <path d="M5.5 12H18.5" />
                      <path d="M12 3.5V20.5" />
                    </svg>
                  </div>
                  <div className="ml-2">
                    <p className="text-sm font-medium">Ambulance Service</p>
                    <p className="text-xs text-gray-500">108</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Navigation Menu */}
            <nav className="py-2 px-4 mt-2">
              <h3 className="font-medium text-sm uppercase text-gray-500 mb-2">Quick Links</h3>
              <ul className="space-y-1">
                <li>
                  <a href="#" className="flex items-center px-3 py-2 text-primary font-medium bg-gray-50 rounded-md">
                    <Home className="mr-3 h-4 w-4" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center px-3 py-2 hover:bg-gray-50 rounded-md">
                    <Map className="mr-3 h-4 w-4" />
                    Saved Routes
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center px-3 py-2 hover:bg-gray-50 rounded-md">
                    <History className="mr-3 h-4 w-4" />
                    Route History
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center px-3 py-2 hover:bg-gray-50 rounded-md">
                    <Users className="mr-3 h-4 w-4" />
                    Trusted Contacts
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center px-3 py-2 hover:bg-gray-50 rounded-md">
                    <Settings className="mr-3 h-4 w-4" />
                    Settings
                  </a>
                </li>
                <li>
                  <a href="#" className="flex items-center px-3 py-2 hover:bg-gray-50 rounded-md">
                    <HelpCircle className="mr-3 h-4 w-4" />
                    Help & Support
                  </a>
                </li>
              </ul>
            </nav>
          </>
        )}
      </div>
    </div>
  );
};

// Helper component for the search icon
const SearchIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <circle cx="11" cy="11" r="8" />
    <path d="m21 21-4.3-4.3" />
  </svg>
);

export default SidePanel;
