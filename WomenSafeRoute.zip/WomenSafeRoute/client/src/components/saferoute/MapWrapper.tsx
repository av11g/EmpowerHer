import React, { memo } from 'react';
import { useMapProvider } from '@/hooks/use-map-provider';
import MapContainer from './MapContainer';
import SimpleMapboxContainer from './SimpleMapboxContainer';
import { Loader2, AlertTriangle } from 'lucide-react';

const MapWrapper: React.FC = () => {
  const {
    currentProvider,
    setProvider,
    googleMapRef,
    mapboxMapRef,
    isGoogleMapsAvailable,
    isMapboxAvailable
  } = useMapProvider();

  // Loading state if checking providers
  if (!isGoogleMapsAvailable && !isMapboxAvailable) {
    return (
      <div className="map-container w-full h-full flex items-center justify-center bg-slate-100">
        <div className="text-center p-4 max-w-md">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
            <h3 className="text-lg font-semibold mt-4 mb-2">Loading Map Provider</h3>
            <p className="text-gray-600 mb-4">
              We're setting up the best map provider for your experience...
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
              <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state if no map providers are available
  if ((!isGoogleMapsAvailable && !isMapboxAvailable) || (currentProvider === 'mapbox' && !isMapboxAvailable)) {
    return (
      <div className="map-container w-full h-full flex flex-col items-center justify-center bg-slate-100">
        <div className="p-6 max-w-md bg-white rounded-lg shadow-md text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-700 mb-2">Map Provider Error</h2>
          <p className="text-gray-700">
            We couldn't load any map providers. Please check your internet connection and try again.
          </p>
          <p className="mt-4 text-sm text-gray-500">
            If the problem persists, please contact support.
          </p>
        </div>
      </div>
    );
  }

  // Provider selector UI (optional, can be used to manually switch providers)
  const ProviderSelector = () => (
    <div className="absolute top-4 right-4 z-10">
      <div className="bg-white rounded-md shadow-md p-2 flex items-center space-x-2">
        <button
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            currentProvider === 'google'
              ? 'bg-primary text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
          onClick={() => isGoogleMapsAvailable && setProvider('google')}
          disabled={!isGoogleMapsAvailable}
        >
          Google Maps
        </button>
        <button
          className={`px-3 py-1 rounded-md text-sm font-medium ${
            currentProvider === 'mapbox'
              ? 'bg-primary text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
          onClick={() => isMapboxAvailable && setProvider('mapbox')}
          disabled={!isMapboxAvailable}
        >
          Mapbox
        </button>
      </div>
    </div>
  );

  // Render the appropriate map container based on the current provider
  return (
    <div className="relative w-full h-full">
      {/* Show Google Maps if it's the current provider */}
      {currentProvider === 'google' && isGoogleMapsAvailable && (
        <MapContainer mapRef={googleMapRef} />
      )}

      {/* Show Mapbox if it's the current provider or Google Maps is not available */}
      {(currentProvider === 'mapbox' || !isGoogleMapsAvailable) && isMapboxAvailable && (
        <SimpleMapboxContainer mapRef={mapboxMapRef} />
      )}

      {/* Uncomment to display the provider selector */}
      {/* <ProviderSelector /> */}
    </div>
  );
};

export default memo(MapWrapper);