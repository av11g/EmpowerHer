import React from 'react';
import { AlertCircle, Navigation2, Clock, Map, Sun, Users } from 'lucide-react';
import { Route } from '@shared/schema';

interface RouteInfoProps {
  route: Route;
  onClose: () => void;
  onNavigate: () => void;
}

const RouteInfo: React.FC<RouteInfoProps> = ({ route, onClose, onNavigate }) => {
  const getSafetyLevelClass = (safetyLevel: string) => {
    switch (safetyLevel) {
      case 'safe':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'moderate':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'danger':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSafetyScoreColor = (score: number) => {
    if (score >= 75) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  const safetyLevelClass = getSafetyLevelClass(route.safety_level);
  const safetyScoreColor = getSafetyScoreColor(route.safety_score);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className={`p-4 ${safetyLevelClass} border-b`}>
        <div className="flex justify-between items-start">
          <h3 className="font-semibold text-lg">{route.name}</h3>
          <button 
            onClick={onClose}
            className="p-1 rounded-full hover:bg-white/20"
          >
            ✕
          </button>
        </div>
        <div className="flex items-center space-x-3 mt-2">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            <span className="text-sm">{route.duration} min</span>
          </div>
          <div className="flex items-center">
            <Map className="h-4 w-4 mr-1" />
            <span className="text-sm">{route.distance} km</span>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="mb-4">
          <h4 className="text-sm font-medium text-gray-700 mb-2">Safety Information</h4>
          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-md">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 mr-2 text-gray-600" />
              <span className="text-sm font-medium">Safety Score</span>
            </div>
            <span className={`text-lg font-bold ${safetyScoreColor}`}>
              {route.safety_score}/100
            </span>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Sun className="h-4 w-4 mr-2 text-gray-600" />
              <span className="text-sm">Lighting</span>
            </div>
            <span className="text-sm font-medium">{route.lighting}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-2 text-gray-600" />
              <span className="text-sm">Foot Traffic</span>
            </div>
            <span className="text-sm font-medium">{route.foot_traffic}</span>
          </div>
        </div>

        <div className="mt-6">
          <button
            onClick={onNavigate}
            className="w-full bg-primary text-white py-2 px-4 rounded-md flex items-center justify-center hover:bg-primary/90 transition-colors"
          >
            <Navigation2 className="h-4 w-4 mr-2" />
            Navigate
          </button>
        </div>
      </div>
    </div>
  );
};

export default RouteInfo;