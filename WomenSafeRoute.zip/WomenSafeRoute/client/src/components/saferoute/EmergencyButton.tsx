import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useWebSocket } from '@/hooks/use-websocket';
import { useToast } from '@/hooks/use-toast';

const EmergencyButton: React.FC = () => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [emergencyMessage, setEmergencyMessage] = useState('');
  const [sendingAlert, setSendingAlert] = useState(false);

  const { sendEmergencyAlert } = useWebSocket();
  const { toast } = useToast();

  const handleEmergencyClick = () => {
    setDialogOpen(true);
    toast({
      title: "SOS Button Pressed",
      description: "Opening emergency options...",
      variant: "destructive",
      duration: 3000,
    });
  };

  const handleSendAlert = () => {
    setSendingAlert(true);

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };

          sendEmergencyAlert(
            emergencyMessage || 'Help needed at my location!', 
            userLocation
          );

          toast({
            title: "Emergency Alert Activated",
            description: "Alerting nearby users and emergency services. Delhi Police: 100, Ambulance: 102",
            variant: "destructive",
            duration: 5000,
          });

          setDialogOpen(false);
          setSendingAlert(false);
          setEmergencyMessage('');
        },
        (error) => {
          console.error('Error getting location:', error);
          toast({
            title: "Location Error",
            description: "Could not get your location. Please try again.",
            variant: "destructive",
            duration: 3000,
          });
          setSendingAlert(false);
        }
      );
    }
  };

  return (
    <>
      <Button 
        variant="destructive" 
        size="lg"
        className="fixed bottom-4 right-4 z-50"
        onClick={handleEmergencyClick}
      >
        SOS Emergency
      </Button>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Emergency Alert</DialogTitle>
          </DialogHeader>
          <Textarea
            value={emergencyMessage}
            onChange={(e) => setEmergencyMessage(e.target.value)}
            placeholder="Describe your emergency situation (optional)"
            className="min-h-[100px]"
          />
          <DialogFooter>
            <Button
              variant="destructive"
              onClick={handleSendAlert}
              disabled={sendingAlert}
            >
              {sendingAlert ? 'Sending Alert...' : 'Send Emergency Alert'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default EmergencyButton;