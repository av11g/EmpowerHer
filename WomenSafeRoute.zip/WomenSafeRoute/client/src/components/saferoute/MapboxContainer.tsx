import React, { useRef, useState, useEffect, useCallback } from 'react';
import { mapboxgl, mapboxTokenSet } from '@/lib/mapbox-config';
import { useWebSocket } from '@/hooks/use-websocket';
import { useSafetyMap } from '@/hooks/use-safety-map';
import { CrimeIncident, Route, ServiceLocation } from '@shared/schema';
import { AlertTriangle, Loader2 } from 'lucide-react';
import { getSafetyLevelColor } from '@/utils/color-utils';
import 'mapbox-gl/dist/mapbox-gl.css';

// Import the Thoothukudi locations
import { thoothukudiLocations } from './MapContainer';

interface MapboxContainerProps {
  mapRef: React.MutableRefObject<mapboxgl.Map | null>;
}

const MapboxContainer: React.FC<MapboxContainerProps> = ({ mapRef }) => {
  const { 
    sendLocationUpdate, 
    nearbyEmergencyServices, 
    nearbyCrimeIncidents 
  } = useWebSocket();

  const {
    routes,
    selectedRoute,
    routeGeoJSON,
    selectRoute
  } = useSafetyMap();

  const [mapError, setMapError] = useState<string | null>(null);
  const [selectedMarker, setSelectedMarker] = useState<ServiceLocation | CrimeIncident | null>(null);
  const [userPosition, setUserPosition] = useState<{ lat: number; lng: number }>({ lat: 8.7638, lng: 78.1348 }); // Thoothukudi center
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchBoxRef = useRef<HTMLDivElement>(null);

  // Mapbox container ref for map initialization
  const mapContainerRef = useRef<HTMLDivElement>(null);

  // Load Mapbox map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Check for valid Mapbox token before creating map
    const initMapbox = async () => {
      // Make sure the token is fetched first if not already set
      if (!mapboxgl.accessToken || mapboxgl.accessToken === '') {
        try {
          const response = await fetch('/api/config');
          if (response.ok) {
            const config = await response.json();
            if (config.mapbox && config.mapbox.accessToken) {
              console.log('Using Mapbox token from server config API');
              mapboxgl.accessToken = config.mapbox.accessToken;
            } else {
              throw new Error('No valid Mapbox token found in server config');
            }
          }
        } catch (error) {
          console.error('Error fetching Mapbox token:', error);
          setMapError('Failed to get Mapbox access token. Please try refreshing the page.');
          return;
        }
      }

      if (!mapboxgl.accessToken || mapboxgl.accessToken === '') {
        setMapError('Mapbox access token not found. Map cannot be displayed.');
        return;
      }

      try {
        const mapContainer = mapContainerRef.current;
        if (!mapContainer) return;

        const map = new mapboxgl.Map({
          container: mapContainer,
          style: 'mapbox://styles/mapbox/streets-v12',
          center: [userPosition.lng, userPosition.lat], // Mapbox uses [lng, lat] format
          zoom: 14
        });

      // Save map reference
      mapRef.current = map;

      // Add navigation controls
      map.addControl(new mapboxgl.NavigationControl(), 'top-right');

      // Add navigation controls and custom arrow image when map loads
      map.on('load', () => {
        // Add custom arrow icon for route navigation
        try {
          map.loadImage(
            'https://raw.githubusercontent.com/mapbox/mapbox-gl-js/master/src/style-spec/reference/img/arrow.png',
            (error, image) => {
              if (error) throw error;
              if (!image) return;

              if (!map.hasImage('arrow')) {
                map.addImage('arrow', image as any);
              }
            }
          );
        } catch (err) {
          console.error('Error loading arrow image:', err);
        }
      });

      // Add user location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            const newPos = { lat: latitude, lng: longitude };
            setUserPosition(newPos);
            map.flyTo({
              center: [longitude, latitude],
              zoom: 14
            });
            sendLocationUpdate(latitude, longitude);

            // Add user marker
            new mapboxgl.Marker({ color: '#007bff' })
              .setLngLat([longitude, latitude])
              .addTo(map);
          },
          (err) => {
            console.warn('Geolocation error:', err);
            // Still send default location if geolocation fails
            sendLocationUpdate(userPosition.lat, userPosition.lng);

            // Add default user marker
            new mapboxgl.Marker({ color: '#007bff' })
              .setLngLat([userPosition.lng, userPosition.lat])
              .addTo(map);
          }
        );
      } else {
        // Use default location if geolocation not supported
        sendLocationUpdate(userPosition.lat, userPosition.lng);

        // Add default user marker
        new mapboxgl.Marker({ color: '#007bff' })
          .setLngLat([userPosition.lng, userPosition.lat])
          .addTo(map);
      }

      // Add markers for Thoothukudi locations
      thoothukudiLocations.forEach((location, index) => {
        const marker = new mapboxgl.Marker({ color: '#FFBB00' })
          .setLngLat([location.location.lng, location.location.lat])
          .setPopup(new mapboxgl.Popup().setHTML(`<h3>${location.name}</h3><p>${location.address}</p>`))
          .addTo(map);
      });

        // Add cleanup
      return () => {
        map.remove();
        mapRef.current = null;
      };
    } catch (error) {
      console.error('Mapbox initialization error:', error);
      setMapError('Failed to initialize Mapbox. Please check your internet connection and try again.');
    }
    };

    // Call the initialization function
    initMapbox();

  }, [mapRef, userPosition.lat, userPosition.lng, sendLocationUpdate]);

  // Add/update routes when route data changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;

    try {
      // First, clean up any existing layers and sources
      const style = map.getStyle();
      if (style && style.layers) {
        style.layers.forEach(layer => {
          if (layer.id.startsWith('route-') || layer.id.startsWith('route-outline-') || layer.id.startsWith('route-arrows-')) {
            if (map.getLayer(layer.id)) {
              map.removeLayer(layer.id);
            }
          }
        });
      }

      // Clean up sources
      for (let i = 0; i < 20; i++) { // Arbitrary high number to ensure we get all possible sources
        if (map.getSource(`route-source-${i}`)) {
          try {
            map.removeSource(`route-source-${i}`);
          } catch (e) {
            console.log(`Could not remove source route-source-${i}: ${e}`);
          }
        }
      }

      // Add new routes with enhanced styling for safety visualization
      routeGeoJSON.forEach((route, index) => {
        // Safety styling - should be:
        // - Green for safe routes
        // - Yellow for moderately safe routes
        // - Red for unsafe/dangerous routes
        let isSelected = selectedRoute && routes[index] && selectedRoute.id === routes[index].id;
        let safetyLevel = route.properties.safety_level;
        let safetyColor = getSafetyLevelColor(safetyLevel);

        try {
          // Debug the route details
          console.log(`Processing route ${index}:`, {
            id: routes[index]?.id,
            name: routes[index]?.name,
            safety_level: route.properties.safety_level,
            coordinates: JSON.stringify(route.geometry.coordinates)
          });

          // Validate coordinates
          if (!route.geometry.coordinates || !Array.isArray(route.geometry.coordinates) || route.geometry.coordinates.length < 2) {
            console.error(`Invalid coordinates for route ${index}:`, route.geometry.coordinates);
            return; // Skip this route
          }

          // Ensure all coordinates are valid arrays of [lng, lat]
          const validCoordinates = route.geometry.coordinates.filter(coord => 
            Array.isArray(coord) && coord.length === 2 && 
            typeof coord[0] === 'number' && typeof coord[1] === 'number'
          );

          if (validCoordinates.length < 2) {
            console.error(`Not enough valid coordinates for route ${index}:`, route.geometry.coordinates);
            return; // Skip this route
          }

          // Create a valid GeoJSON source
          const featureData = {
            type: 'Feature' as const,
            properties: { ...route.properties },
            geometry: {
              type: 'LineString' as const,
              coordinates: validCoordinates
            }
          };

          // Add the source
          map.addSource(`route-source-${index}`, {
            type: 'geojson',
            data: featureData
          });

          // Simpler approach - just highlight the selected route with increased width

          // Different pattern styles based on safety level
          let dashArray: number[] = [];
          if (safetyLevel === 'safe') {
            dashArray = []; // Solid line for safe routes
          } else if (safetyLevel === 'moderate') {
            dashArray = [2, 1]; // Dashed line for moderate routes
          } else if (safetyLevel === 'danger') {
            dashArray = [0.5, 0.5]; // Dotted line for dangerous routes
          }

          // Add glow effect for selected routes
          if (isSelected) {
            // Add glow effect (larger, blurred outline)
            map.addLayer({
              id: `route-glow-${index}`,
              type: 'line',
              source: `route-source-${index}`,
              layout: {
                'line-join': 'round',
                'line-cap': 'round'
              },
              paint: {
                'line-color': safetyColor,
                'line-width': 16,
                'line-opacity': 0.4,
                'line-blur': 3
              }
            });
          }

          // Add outline for better visibility
          map.addLayer({
            id: `route-outline-${index}`,
            type: 'line',
            source: `route-source-${index}`,
            layout: {
              'line-join': 'round',
              'line-cap': 'round'
            },
            paint: {
              'line-color': '#000',
              'line-width': isSelected ? 12 : 6,
              'line-opacity': isSelected ? 0.8 : 0.5,
              'line-dasharray': dashArray.length > 0 ? dashArray : undefined
            }
          });

          // Add main colored route line
          map.addLayer({
            id: `route-${index}`,
            type: 'line',
            source: `route-source-${index}`,
            layout: {
              'line-join': 'round',
              'line-cap': 'round',
              'visibility': 'visible'
            },
            paint: {
              'line-color': safetyColor,
              'line-width': isSelected ? 8 : 4,
              'line-opacity': isSelected ? 1 : 0.8,
              'line-dasharray': dashArray.length > 0 ? dashArray : undefined
            },
            minzoom: 0,
            maxzoom: 22
          });

          // Add hover effect for better visibility
          map.addLayer({
            id: `route-hover-${index}`,
            type: 'line',
            source: `route-source-${index}`,
            layout: {
              'line-join': 'round',
              'line-cap': 'round',
              'visibility': 'visible'
            },
            paint: {
              'line-color': safetyColor,
              'line-width': isSelected ? 12 : 8,
              'line-opacity': 0,
              'line-blur': 1
            },
            minzoom: 0,
            maxzoom: 22
          });

          // Add click handler to select route
          map.on('click', `route-${index}`, () => {
            if (routes[index]) {
              // Add a slight zoom/fly animation to focus on the route
              const coordinates = route.geometry.coordinates;
              if (coordinates.length > 0) {
                // Find the center of the route
                const bounds = coordinates.reduce(
                  (bounds, coord) => bounds.extend(coord as [number, number]),
                  new mapboxgl.LngLatBounds(coordinates[0] as [number, number], coordinates[0] as [number, number])
                );

                map.fitBounds(bounds, {
                  padding: 50,
                  duration: 600
                });
              }

              // Select the route
              selectRoute(routes[index]);
            }
          });

          // Add hover effect
          map.on('mouseenter', `route-${index}`, () => {
            map.getCanvas().style.cursor = 'pointer';
          });

          map.on('mouseleave', `route-${index}`, () => {
            map.getCanvas().style.cursor = '';
          });

        } catch (error) {
          console.error(`Error adding route ${index}:`, error);
          console.log(`Route data for route ${index}:`, {
            route: routes[index],
            geoJSON: route,
            coordinates: route.geometry.coordinates
          });
        }
      });

      // If a route is selected, make sure it's visible in the viewport and add markers for start/end
      if (selectedRoute) {
        const selectedRouteIndex = routes.findIndex(r => r.id === selectedRoute.id);
        if (selectedRouteIndex !== -1 && routeGeoJSON[selectedRouteIndex]) {
          const coordinates = routeGeoJSON[selectedRouteIndex].geometry.coordinates;
          if (coordinates && coordinates.length > 0) {
            // Create bounds that contain all route coordinates
            const bounds = coordinates.reduce(
              (bounds, coord) => bounds.extend(coord as [number, number]),
              new mapboxgl.LngLatBounds(coordinates[0] as [number, number], coordinates[0] as [number, number])
            );

            // Fit the map to these bounds
            map.fitBounds(bounds, {
              padding: 60,
              duration: 800
            });

            // Clear previous markers (this was causing an error)
            try {
              // Use a safer approach to remove markers
              const mapDiv = map.getContainer();
              const existingStartMarkers = mapDiv.querySelectorAll('.mapboxgl-marker.route-start-marker');
              existingStartMarkers.forEach(marker => marker.remove());
              const existingEndMarkers = mapDiv.querySelectorAll('.mapboxgl-marker.route-end-marker');
              existingEndMarkers.forEach(marker => marker.remove());
            } catch (error) {
              console.log("Error removing markers:", error);
            }

            // Add start point marker (green)
            const startPoint = coordinates[0] as [number, number];
            const startMarkerElement = document.createElement('div');
            startMarkerElement.className = 'route-start-marker';
            startMarkerElement.style.width = '25px';
            startMarkerElement.style.height = '25px';
            startMarkerElement.style.borderRadius = '50%';
            startMarkerElement.style.backgroundColor = '#4CAF50'; // Green
            startMarkerElement.style.border = '3px solid white';
            startMarkerElement.style.boxShadow = '0 0 5px rgba(0,0,0,0.5)';
            startMarkerElement.style.display = 'flex';
            startMarkerElement.style.justifyContent = 'center';
            startMarkerElement.style.alignItems = 'center';
            startMarkerElement.innerHTML = '<span style="color:white;font-weight:bold;">A</span>';

            new mapboxgl.Marker(startMarkerElement)
              .setLngLat(startPoint)
              .setPopup(new mapboxgl.Popup({ offset: 25 }).setText('Starting Point'))
              .addTo(map);

            // Add end point marker (red)
            const endPoint = coordinates[coordinates.length - 1] as [number, number];
            const endMarkerElement = document.createElement('div');
            endMarkerElement.className = 'route-end-marker';
            endMarkerElement.style.width = '25px';
            endMarkerElement.style.height = '25px';
            endMarkerElement.style.borderRadius = '50%';
            endMarkerElement.style.backgroundColor = '#F44336'; // Red
            endMarkerElement.style.border = '3px solid white';
            endMarkerElement.style.boxShadow = '0 0 5px rgba(0,0,0,0.5)';
            endMarkerElement.style.display = 'flex';
            endMarkerElement.style.justifyContent = 'center';
            endMarkerElement.style.alignItems = 'center';
            endMarkerElement.innerHTML = '<span style="color:white;font-weight:bold;">B</span>';

            new mapboxgl.Marker(endMarkerElement)
              .setLngLat(endPoint)
              .setPopup(new mapboxgl.Popup({ offset: 25 }).setText('Destination'))
              .addTo(map);
          }
        }
      }

    } catch (error) {
      console.error("Error updating routes:", error);
    }
  }, [mapRef, routeGeoJSON, routes, selectedRoute, selectRoute]);

  // Add/update emergency services markers when data changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !nearbyEmergencyServices) return;

    // Remove existing markers (if needed)
    const existingMarkers = document.querySelectorAll('.emergency-service-marker');
    existingMarkers.forEach(marker => marker.remove());

    // Add new markers
    nearbyEmergencyServices.forEach((service) => {
      // Create custom marker element
      const markerElement = document.createElement('div');
      markerElement.className = 'emergency-service-marker';
      markerElement.style.width = '32px';
      markerElement.style.height = '32px';
      markerElement.style.backgroundImage = service.type === 'police' 
        ? 'url(https://maps.google.com/mapfiles/ms/icons/police.png)'
        : 'url(https://maps.google.com/mapfiles/ms/icons/hospitals.png)';
      markerElement.style.backgroundSize = 'contain';
      markerElement.style.cursor = 'pointer';

      // Create popup
      const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
        `<h3>${service.name}</h3>
         <p>${service.type === 'police' ? 'Police Station' : 'Hospital'}</p>
         <p>${service.address || 'Thoothukudi'}</p>
         <p>Distance: ${service.distance}</p>`
      );

      // Add marker to map
      new mapboxgl.Marker(markerElement)
        .setLngLat([service.longitude, service.latitude])
        .setPopup(popup)
        .addTo(map);
    });
  }, [mapRef, nearbyEmergencyServices]);

  // Add/update crime incident markers when data changes
  useEffect(() => {
    const map = mapRef.current;
    if (!map || !nearbyCrimeIncidents) return;

    // Remove existing markers (if needed)
    const existingMarkers = document.querySelectorAll('.crime-incident-marker');
    existingMarkers.forEach(marker => marker.remove());

    // Add new markers
    nearbyCrimeIncidents.forEach((incident) => {
      // Create custom marker element
      const markerElement = document.createElement('div');
      markerElement.className = 'crime-incident-marker';
      markerElement.style.width = '24px';
      markerElement.style.height = '24px';
      markerElement.style.backgroundImage = 'url(https://maps.google.com/mapfiles/ms/icons/red-dot.png)';
      markerElement.style.backgroundSize = 'contain';
      markerElement.style.cursor = 'pointer';

      // Create popup
      const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(
        `<h3>${incident.incident_type}</h3>
         <p>${incident.description || 'No description available'}</p>
         <p>Date: ${new Date(incident.incident_date).toLocaleDateString()}</p>`
      );

      // Add marker to map
      new mapboxgl.Marker(markerElement)
        .setLngLat([incident.longitude, incident.latitude])
        .setPopup(popup)
        .addTo(map);
    });
  }, [mapRef, nearbyCrimeIncidents]);

  // Set up geolocation tracking
  useEffect(() => {
    let watchId: number | null = null;

    if (navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserPosition({ lat: latitude, lng: longitude });
          sendLocationUpdate(latitude, longitude);

          // Update user marker position if map is loaded
          if (mapRef.current) {
            // Remove existing user position markers
            const existingMarkers = document.querySelectorAll('.user-position-marker');
            existingMarkers.forEach(marker => marker.remove());

            // Add new user marker
            const markerElement = document.createElement('div');
            markerElement.className = 'user-position-marker';
            markerElement.style.width = '40px';
            markerElement.style.height = '40px';
            markerElement.style.backgroundImage = 'url(https://maps.google.com/mapfiles/ms/icons/blue-dot.png)';
            markerElement.style.backgroundSize = 'contain';

            new mapboxgl.Marker(markerElement)
              .setLngLat([longitude, latitude])
              .addTo(mapRef.current);
          }
        },
        (error) => {
          console.error('Error tracking location:', error);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 10000,
          timeout: 10000
        }
      );
    }

    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [mapRef, sendLocationUpdate]);

  // Handle map error
  if (mapError) {
    return (
      <div className="map-container w-full h-full flex flex-col items-center justify-center bg-slate-100">
        <div className="p-6 max-w-md bg-white rounded-lg shadow-md text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-700 mb-2">Map Loading Error</h2>
          <p className="text-gray-700">{mapError}</p>
          <p className="mt-4 text-sm text-gray-500">
            Please check your internet connection or try again later.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="map-container w-full h-full relative">
      {/* User guidance notification */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10 px-4 py-2 bg-white rounded-lg shadow-lg text-sm text-center">
        <p className="font-medium text-primary">Use the sidebar panel to search for safe routes in Thoothukudi</p>
      </div>

      {/* Mapbox container */}
      <div 
        ref={mapContainerRef} 
        className="w-full h-full"
        style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0 }}
      />
    </div>
  );
};

// Add this function to handle Mapbox token initialization.  You'll need to adapt this to your actual implementation
const initMapboxToken = async () => {
    try {
      const response = await fetch('/api/config');
      if (!response.ok) {
        throw new Error('Failed to fetch map configuration');
      }
      const config = await response.json();
      if (!config.mapbox || !config.mapbox.accessToken) {
        throw new Error('No valid Mapbox token found in server response');
      }
      mapboxgl.accessToken = config.mapbox.accessToken;
      return true;
    } catch (error) {
      console.error('Error initializing Mapbox token:', error);
      return false;
    }
  };

export default MapboxContainer;