import React, { useState } from 'react';
import { Search, MapPin, Navigation } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useSafetyMap } from '@/hooks/use-safety-map';

interface RouteSearchProps {
  onSelectRoute: (routeId: number) => void;
}

const RouteSearch: React.FC<RouteSearchProps> = ({ onSelectRoute }) => {
  const { routes } = useSafetyMap();
  const [source, setSource] = useState('');
  const [destination, setDestination] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showResults, setShowResults] = useState(false);

  // Predefined locations in Thoothukudi
  const predefinedLocations = [
    { name: 'Thoothukudi Central', value: 'central' },
    { name: 'VOC Port', value: 'voc port' },
    { name: 'Medical College', value: 'medical college' },
    { name: 'Harbor Beach', value: 'harbor beach' },
    { name: 'Bus Stand', value: 'bus stand' },
    { name: 'Railway Station', value: 'railway station' },
    { name: 'Anna Nagar', value: 'anna nagar' },
    { name: 'Millerpuram', value: 'millerpuram' },
    { name: 'Third Mile', value: 'third mile' }
  ];

  const handleSearch = () => {
    if (!source || !destination) {
      alert('Please enter both source and destination');
      return;
    }

    // Filter routes based on source and destination
    const filteredRoutes = routes.filter(route => {
      const routeName = route.name.toLowerCase();
      const sourceText = source.toLowerCase();
      const destinationText = destination.toLowerCase();
      
      return (
        (routeName.includes(sourceText) && routeName.includes(destinationText)) ||
        (routeName.includes('central') && (
          routeName.includes(destinationText) || 
          (destinationText.includes('medical') && routeName.includes('medical')) ||
          (destinationText.includes('voc') && routeName.includes('voc')) ||
          (destinationText.includes('harbor') && routeName.includes('harbor'))
        ))
      );
    });

    setSearchResults(filteredRoutes);
    setShowResults(true);
  };

  const handleSourceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSource(e.target.value);
    setShowResults(false);
  };

  const handleDestinationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setDestination(e.target.value);
    setShowResults(false);
  };

  const handleSelectRoute = (routeId: number) => {
    onSelectRoute(routeId);
    setShowResults(false);
  };

  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-lg font-semibold mb-4 text-primary">Find Safe Routes</h2>
      
      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-primary" />
          <Input
            placeholder="Starting point (e.g., Central)"
            value={source}
            onChange={handleSourceChange}
            className="flex-1"
            list="source-locations"
          />
          <datalist id="source-locations">
            {predefinedLocations.map((loc, index) => (
              <option key={`source-${index}`} value={loc.name} />
            ))}
          </datalist>
        </div>
        
        <div className="flex items-center space-x-2">
          <MapPin className="h-5 w-5 text-red-500" />
          <Input
            placeholder="Destination (e.g., Medical College)"
            value={destination}
            onChange={handleDestinationChange}
            className="flex-1"
            list="destination-locations"
          />
          <datalist id="destination-locations">
            {predefinedLocations.map((loc, index) => (
              <option key={`dest-${index}`} value={loc.name} />
            ))}
          </datalist>
        </div>
        
        <Button 
          className="w-full" 
          onClick={handleSearch}
        >
          <Search className="h-4 w-4 mr-2" />
          Find Routes
        </Button>
      </div>
      
      {showResults && (
        <div className="mt-4 space-y-2">
          <h3 className="font-medium text-sm text-gray-500">
            {searchResults.length === 0 
              ? 'No routes found. Try different locations.' 
              : `Found ${searchResults.length} routes:`}
          </h3>
          
          {searchResults.map((route) => {
            // Determine the color based on safety level
            let bgColor, textColor;
            switch (route.safety_level) {
              case 'safe':
                bgColor = 'bg-green-100';
                textColor = 'text-green-800';
                break;
              case 'moderate':
                bgColor = 'bg-yellow-100';
                textColor = 'text-yellow-800';
                break;
              case 'danger':
                bgColor = 'bg-red-100';
                textColor = 'text-red-800';
                break;
              default:
                bgColor = 'bg-gray-100';
                textColor = 'text-gray-800';
            }
            
            return (
              <div 
                key={route.id} 
                className={`p-3 ${bgColor} rounded-md cursor-pointer transition-all hover:shadow-md`}
                onClick={() => handleSelectRoute(route.id)}
              >
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className={`font-medium ${textColor}`}>{route.name}</h4>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <span className="mr-3">{route.distance} km</span>
                      <span>{route.duration} min</span>
                    </div>
                    <div className="mt-1 text-xs">
                      <span className={`inline-block px-2 py-0.5 rounded ${textColor} ${bgColor} border border-current`}>
                        {route.safety_level.charAt(0).toUpperCase() + route.safety_level.slice(1)}
                      </span>
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="outline"
                    className="flex items-center space-x-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectRoute(route.id);
                    }}
                  >
                    <Navigation className="h-3 w-3" />
                    <span>Navigate</span>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default RouteSearch;