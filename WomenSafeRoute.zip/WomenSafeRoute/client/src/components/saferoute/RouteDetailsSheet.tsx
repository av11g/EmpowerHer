import React from 'react';
import { Route } from '@shared/schema';
import { getSafetyLevelColor, getSafetyScoreWidth, getLightingIcon, getFootTrafficIcon } from '@/utils/color-utils';

interface RouteDetailsSheetProps {
  isOpen: boolean;
  toggleBottomSheet: () => void;
  routes: Route[];
  selectedRoute: Route | null;
  selectRoute: (route: Route) => void;
}

const RouteDetailsSheet: React.FC<RouteDetailsSheetProps> = ({
  isOpen,
  toggleBottomSheet,
  routes,
  selectedRoute,
  selectRoute
}) => {
  // Calculate transform based on open state
  const transformClass = isOpen ? 'translate-y-0' : 'translate-y-3/4';

  return (
    <div className={`absolute bottom-0 left-0 right-0 bg-white rounded-t-xl shadow-lg z-10 transition-transform duration-300 transform ${transformClass} md:hidden`}>
      {/* Drag Handle */}
      <div 
        className="w-12 h-1 bg-gray-300 rounded-full mx-auto mt-3 mb-2 cursor-pointer"
        onClick={toggleBottomSheet}
      ></div>
      
      {/* Route Details */}
      <div className="px-4 pt-2 pb-4">
        <h2 className="text-lg font-semibold flex justify-between items-center">
          <span>Route Details</span>
        </h2>
        
        {/* Selected Route Details */}
        {selectedRoute && (
          <div className="mt-3 bg-gray-50 p-3 rounded-lg border-l-4" style={{ borderLeftColor: getSafetyLevelColor(selectedRoute.safety_level) }}>
            <h3 className="font-medium text-lg">{selectedRoute.name}</h3>
            
            <div className="mt-2 grid grid-cols-3 gap-2 text-sm">
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-gray-500">Duration</div>
                <div className="font-semibold">{selectedRoute.duration} min</div>
              </div>
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-gray-500">Distance</div>
                <div className="font-semibold">{selectedRoute.distance} km</div>
              </div>
              <div className="bg-white p-2 rounded shadow-sm text-center">
                <div className="text-gray-500">Safety</div>
                <div className="font-semibold" style={{ color: getSafetyLevelColor(selectedRoute.safety_level) }}>
                  {selectedRoute.safety_level.charAt(0).toUpperCase() + selectedRoute.safety_level.slice(1)}
                </div>
              </div>
            </div>
            
            <div className="mt-3 flex space-x-2">
              <div className="flex items-center text-xs text-gray-600">
                <span className="material-icons text-sm mr-1">{getLightingIcon(selectedRoute.lighting)}</span>
                {selectedRoute.lighting}
              </div>
              <div className="flex items-center text-xs text-gray-600">
                <span className="material-icons text-sm mr-1">{getFootTrafficIcon(selectedRoute.foot_traffic)}</span>
                {selectedRoute.foot_traffic}
              </div>
            </div>
            
            {/* Safety score bar */}
            <div className="mt-3">
              <div className="flex justify-between items-center text-xs mb-1">
                <span>Safety Score</span>
                <span className="font-semibold">{selectedRoute.safety_score}/100</span>
              </div>
              <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full" 
                  style={{ 
                    width: getSafetyScoreWidth(selectedRoute.safety_score),
                    backgroundColor: getSafetyLevelColor(selectedRoute.safety_level)
                  }}
                ></div>
              </div>
            </div>
            
            {/* Safety Tips */}
            <div className="mt-3 p-2 bg-yellow-50 border border-yellow-100 rounded">
              <h4 className="text-xs font-semibold flex items-center text-yellow-700">
                <span className="material-icons text-sm mr-1">lightbulb</span>
                Safety Tips
              </h4>
              <p className="text-xs mt-1 text-gray-700">
                {selectedRoute.safety_level === 'safe' 
                  ? 'This is a safe route with good visibility and regular foot traffic.'
                  : selectedRoute.safety_level === 'moderate'
                  ? `This route has ${selectedRoute.lighting}. Stay aware of your surroundings while traveling.`
                  : `This route has ${selectedRoute.lighting} and ${selectedRoute.foot_traffic}. Consider traveling with others or choosing an alternate route.`
                }
              </p>
            </div>
          </div>
        )}
        
        {/* Route Options */}
        <h3 className="text-md font-medium mt-4 mb-2">Available Routes</h3>
        {routes.length > 0 ? (
          <div className="space-y-3">
            {routes.map((route) => (
              <div 
                key={route.id} 
                className={`bg-gray-50 p-3 rounded-lg border ${selectedRoute?.id === route.id ? 'border-primary' : 'border-gray-100'} flex items-center`}
              >
                <div className="flex-shrink-0 mr-3">
                  <div 
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: getSafetyLevelColor(route.safety_level) }}
                  >
                    <span className="material-icons">
                      {route.safety_level === 'safe' ? 'verified' : 
                       route.safety_level === 'moderate' ? 'speed' : 'warning'}
                    </span>
                  </div>
                </div>
                <div className="flex-grow">
                  <h3 className="font-medium">{route.name}</h3>
                  <div className="text-sm text-gray-500 flex items-center">
                    <span className="material-icons text-xs mr-1">schedule</span>
                    {route.duration} min ({route.distance} km)
                  </div>
                </div>
                <button 
                  className={`${selectedRoute?.id === route.id ? 'bg-primary' : 'bg-gray-200 text-gray-700'} px-3 py-1 rounded-md text-sm font-medium shadow-sm hover:bg-opacity-90 text-white`}
                  onClick={() => selectRoute(route)}
                >
                  {selectedRoute?.id === route.id ? 'Selected' : 'Select'}
                </button>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-4 p-3 bg-gray-50 rounded-lg text-center">
            <p className="text-gray-500">No routes available</p>
          </div>
        )}
        
        {/* Safety Legend */}
        <div className="mt-4 bg-gray-50 p-3 rounded-lg">
          <h3 className="text-sm font-medium mb-2">Safety Legend</h3>
          <div className="grid grid-cols-3 gap-2">
            <div className="legend-item flex items-center">
              <div className="legend-color w-4 h-4 rounded-full mr-2" style={{ backgroundColor: getSafetyLevelColor('safe') }}></div>
              <span className="text-xs">Safe</span>
            </div>
            <div className="legend-item flex items-center">
              <div className="legend-color w-4 h-4 rounded-full mr-2" style={{ backgroundColor: getSafetyLevelColor('moderate') }}></div>
              <span className="text-xs">Moderate</span>
            </div>
            <div className="legend-item flex items-center">
              <div className="legend-color w-4 h-4 rounded-full mr-2" style={{ backgroundColor: getSafetyLevelColor('danger') }}></div>
              <span className="text-xs">Caution</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RouteDetailsSheet;
