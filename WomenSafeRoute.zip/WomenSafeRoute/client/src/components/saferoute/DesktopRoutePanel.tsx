import React, { useState } from 'react';
import { Route, ServiceLocation } from '@shared/schema';
import { getSafetyLevelColor, getSafetyScoreWidth, getLightingIcon, getFootTrafficIcon } from '@/utils/color-utils';

interface DesktopRoutePanelProps {
  routes: Route[];
  selectedRoute: Route | null;
  selectRoute: (route: Route) => void;
  serviceLocations: ServiceLocation[];
}

const DesktopRoutePanel: React.FC<DesktopRoutePanelProps> = ({
  routes,
  selectedRoute,
  selectRoute,
  serviceLocations
}) => {
  const [activeTab, setActiveTab] = useState<string>('police');
  
  // Filter services by selected type
  const filteredServices = serviceLocations.filter(
    location => location.type === activeTab
  );

  return (
    <div className="hidden md:block w-80 bg-white border-l shadow-lg h-full overflow-auto z-10">
      {/* Panel Header */}
      <div className="p-4 border-b">
        <h2 className="text-lg font-semibold">Thoothukudi SafeRoute</h2>
        <p className="text-xs text-gray-500 mt-1">Select routes from the list below or use the search function to find specific paths</p>
      </div>
      
      {/* Route Options */}
      <div className="p-4 border-b">
        <h3 className="font-medium mb-3">Available Routes</h3>
        
        {routes.length > 0 ? (
          <div className="space-y-4">
            {routes.map((route) => (
              <div 
                key={route.id} 
                className="bg-gray-50 p-3 rounded-lg border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => selectRoute(route)}
              >
                <div className="flex items-center">
                  <div className="flex-shrink-0 mr-3">
                    <div 
                      className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                      style={{ backgroundColor: getSafetyLevelColor(route.safety_level) }}
                    >
                      <span className="material-icons">
                        {route.safety_level === 'safe' ? 'verified' : 
                         route.safety_level === 'moderate' ? 'speed' : 'warning'}
                      </span>
                    </div>
                  </div>
                  <div className="flex-grow">
                    <h3 className="font-medium">{route.name}</h3>
                    <div className="text-sm text-gray-500 flex items-center">
                      <span className="material-icons text-xs mr-1">schedule</span>
                      {route.duration} min ({route.distance} miles)
                    </div>
                  </div>
                  <input 
                    type="radio" 
                    name="route" 
                    className="h-4 w-4 text-primary focus:ring-primary"
                    checked={selectedRoute?.id === route.id}
                    onChange={() => selectRoute(route)}
                  />
                </div>
                
                <div className="mt-3">
                  <div className="text-xs text-gray-500 mb-1">
                    Safety Score: {
                      route.safety_score >= 75 ? 'Excellent' : 
                      route.safety_score >= 50 ? 'Good' : 
                      'Exercise Caution'
                    }
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="h-2 rounded-full" 
                      style={{ 
                        width: getSafetyScoreWidth(route.safety_score),
                        backgroundColor: getSafetyLevelColor(route.safety_level)
                      }}
                    ></div>
                  </div>
                </div>
                
                <div className="mt-3 flex items-center text-xs text-gray-600">
                  <span className="material-icons text-xs mr-1">
                    {getLightingIcon(route.lighting)}
                  </span>
                  {route.lighting}
                  <span className="mx-2">•</span>
                  <span className="material-icons text-xs mr-1">
                    {getFootTrafficIcon(route.foot_traffic)}
                  </span>
                  {route.foot_traffic} foot traffic
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-4 bg-gray-50 rounded-lg text-center">
            <p className="text-gray-500">No routes available</p>
          </div>
        )}
      </div>
      
      {/* Nearby Services */}
      <div className="p-4">
        <h3 className="font-medium mb-3">Nearby Services</h3>
        
        {/* Service Tabs */}
        <div className="flex border-b">
          <button 
            className={`flex-1 py-2 font-medium text-sm ${activeTab === 'police' ? 'text-primary border-b-2 border-primary' : 'text-gray-600 hover:text-primary'} focus:outline-none`}
            onClick={() => setActiveTab('police')}
          >
            <div className="flex justify-center items-center">
              <span className="material-icons text-sm mr-1">local_police</span>
              Police
            </div>
          </button>
          <button 
            className={`flex-1 py-2 font-medium text-sm ${activeTab === 'hospital' ? 'text-primary border-b-2 border-primary' : 'text-gray-600 hover:text-primary'} focus:outline-none`}
            onClick={() => setActiveTab('hospital')}
          >
            <div className="flex justify-center items-center">
              <span className="material-icons text-sm mr-1">local_hospital</span>
              Hospital
            </div>
          </button>
          <button 
            className={`flex-1 py-2 font-medium text-sm ${activeTab === 'restaurant' ? 'text-primary border-b-2 border-primary' : 'text-gray-600 hover:text-primary'} focus:outline-none`}
            onClick={() => setActiveTab('restaurant')}
          >
            <div className="flex justify-center items-center">
              <span className="material-icons text-sm mr-1">restaurant</span>
              Food
            </div>
          </button>
        </div>
        
        {/* Services List */}
        <div className="mt-3 space-y-3">
          {filteredServices.length > 0 ? (
            filteredServices.map((location) => (
              <div key={location.id} className="flex items-center p-2 hover:bg-gray-50 rounded-md">
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${
                    activeTab === 'police' ? 'bg-blue-500' : 
                    activeTab === 'hospital' ? 'bg-red-500' : 
                    'bg-orange-500'
                  }`}>
                    <span className="material-icons text-sm">
                      {activeTab === 'police' ? 'local_police' : 
                       activeTab === 'hospital' ? 'local_hospital' : 
                       'restaurant'}
                    </span>
                  </div>
                </div>
                <div className="ml-3">
                  <h4 className="text-sm font-medium">{location.name}</h4>
                  <p className="text-xs text-gray-500">
                    {/* This would normally be calculated based on the actual distance */}
                    {(Math.random() * 1.5).toFixed(1)} miles away ({Math.floor(Math.random() * 20) + 5} min)
                  </p>
                </div>
                <button className="ml-auto bg-gray-100 text-gray-600 rounded-full w-8 h-8 flex items-center justify-center hover:bg-gray-200 focus:outline-none">
                  <span className="material-icons text-sm">directions</span>
                </button>
              </div>
            ))
          ) : (
            <div className="p-2 text-center text-gray-500">
              No {activeTab} locations found nearby
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DesktopRoutePanel;
