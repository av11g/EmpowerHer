import React, { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline, DirectionsService, DirectionsRenderer } from '@react-google-maps/api';
import type { CrimeIncident, ServiceLocation, SafetyScore, Route, RouteGeoJSON, ServiceGeoJSON } from '@shared/schema';
import { getSafetyLevelColor, getServiceTypeColor, getServiceTypeIcon } from '@/utils/color-utils';
import { useWebSocket } from '@/hooks/use-websocket';
import { useSafetyMap } from '@/hooks/use-safety-map';
import { AlertCircle, Loader2, Search, X, MapPin, Navigation } from 'lucide-react';
import { googleMapsApiKey, defaultCenter, mapContainerStyle, defaultZoom, mapOptions } from '@/lib/google-maps-config';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

// Define libraries array as a static constant outside the component
// to avoid re-rendering issues with useJsApiLoader
const libraries = ['places'] as ['places'];

// Updated to use Google Maps
interface MapContainerProps {
  mapRef: React.MutableRefObject<google.maps.Map | null>;
}

// Type for search result places
type SearchPlace = {
  name: string;
  address: string;
  location: { lat: number; lng: number };
};

// Thoothukudi common locations for search fallback and directions
export const thoothukudiLocations: SearchPlace[] = [
  {
    name: "Thoothukudi Bus Stand",
    address: "Central Thoothukudi",
    location: { lat: 8.7638, lng: 78.1348 }
  },
  {
    name: "VOC Port",
    address: "Port Area, Thoothukudi",
    location: { lat: 8.7642, lng: 78.1328 }
  },
  {
    name: "Thoothukudi Medical College",
    address: "Thoothukudi",
    location: { lat: 8.7599, lng: 78.1354 }
  },
  {
    name: "Anna Nagar",
    address: "Thoothukudi",
    location: { lat: 8.7660, lng: 78.1420 }
  },
  {
    name: "Millerpuram",
    address: "Thoothukudi",
    location: { lat: 8.7541, lng: 78.1368 }
  },
  {
    name: "Thoothukudi Railway Station",
    address: "Station Area, Thoothukudi",
    location: { lat: 8.7661, lng: 78.1292 }
  },
  {
    name: "Third Mile",
    address: "Thoothukudi",
    location: { lat: 8.7712, lng: 78.1343 }
  },
  {
    name: "VVD Signal", 
    address: "Central Thoothukudi",
    location: { lat: 8.7599, lng: 78.1354 }
  },
  {
    name: "Harbor Beach",
    address: "Beach Road, Thoothukudi",
    location: { lat: 8.7658, lng: 78.1158 }
  },
  {
    name: "Market Street",
    address: "Central Thoothukudi", 
    location: { lat: 8.7645, lng: 78.1372 }
  },
  {
    name: "Bryant Nagar",
    address: "Thoothukudi",
    location: { lat: 8.7705, lng: 78.1423 }
  },
  {
    name: "Beach Road",
    address: "Coastal Thoothukudi",
    location: { lat: 8.7650, lng: 78.1210 }
  },
  {
    name: "VOC College",
    address: "Educational District, Thoothukudi",
    location: { lat: 8.7595, lng: 78.1434 }
  },
  {
    name: "Korampallam",
    address: "Thoothukudi Outskirts",
    location: { lat: 8.7830, lng: 78.1128 }
  },
  {
    name: "Muthiahpuram",
    address: "North Thoothukudi",
    location: { lat: 8.7785, lng: 78.1300 }
  }
];

const MapContainer: React.FC<MapContainerProps> = ({ mapRef }) => {
  const { 
    sendLocationUpdate, 
    nearbyEmergencyServices, 
    nearbyCrimeIncidents 
  } = useWebSocket();
  
  const {
    routes,
    selectedRoute,
    routeGeoJSON,
    selectRoute
  } = useSafetyMap();
  
  const [mapError, setMapError] = useState<string | null>(null);
  const [selectedMarker, setSelectedMarker] = useState<ServiceLocation | CrimeIncident | null>(null);
  const [userPosition, setUserPosition] = useState<google.maps.LatLngLiteral>(defaultCenter);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchPlace[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [showSearchResults, setShowSearchResults] = useState(false);
  const searchBoxRef = useRef<HTMLDivElement>(null);
  
  // Google Maps Directions state
  const [directionsResponse, setDirectionsResponse] = useState<google.maps.DirectionsResult | null>(null);
  const [directionsOptions, setDirectionsOptions] = useState<google.maps.DirectionsRequest | null>(null);
  const [directionsCallback, setDirectionsCallback] = useState<(() => void) | null>(null);

  // Load Google Maps API
  const { isLoaded, loadError } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey,
    libraries // Use the static libraries array
  });

  // Click outside search results handler
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchBoxRef.current && !searchBoxRef.current.contains(event.target as Node)) {
        setShowSearchResults(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  // Function to calculate and display directions between two locations
  const calculateDirections = useCallback((origin: google.maps.LatLngLiteral, destination: google.maps.LatLngLiteral, safetyLevel: 'safe' | 'moderate' | 'danger' = 'safe') => {
    if (!isLoaded) {
      console.warn('Google Maps API not loaded yet');
      return;
    }
    
    // Configure directions request
    const directionsRequest: google.maps.DirectionsRequest = {
      origin,
      destination,
      travelMode: google.maps.TravelMode.WALKING,
      optimizeWaypoints: true,
      provideRouteAlternatives: true,
      avoidHighways: true,
      avoidTolls: true
    };
    
    setDirectionsOptions(directionsRequest);
    
    // Create callback to handle completion
    setDirectionsCallback(() => {
      return () => {
        // Clean up
        setDirectionsOptions(null);
      };
    });
  }, [isLoaded]);

  // Search for a location
  const handleSearch = useCallback(() => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    
    // Try to use Google Places API if available
    if (isLoaded && window.google && window.google.maps && window.google.maps.places) {
      try {
        const placesService = new google.maps.places.PlacesService(document.createElement('div'));
        
        // Biasing search to Thoothukudi region
        const request = {
          query: `${searchQuery} Thoothukudi`, // Append Thoothukudi to search
          fields: ['name', 'geometry', 'formatted_address'],
          locationBias: {
            center: { lat: 8.7638, lng: 78.1348 }, // Thoothukudi center
            radius: 5000 // 5km radius
          }
        };
        
        placesService.findPlaceFromQuery(request, (results, status) => {
          if (status === google.maps.places.PlacesServiceStatus.OK && results) {
            const mappedResults: SearchPlace[] = results.map(place => ({
              name: place.name || 'Unknown place',
              address: place.formatted_address || 'Thoothukudi',
              location: {
                lat: place.geometry?.location?.lat() || defaultCenter.lat,
                lng: place.geometry?.location?.lng() || defaultCenter.lng
              }
            }));
            
            setSearchResults(mappedResults);
            setShowSearchResults(true);
          } else {
            // Fallback to predefined Thoothukudi locations
            const filteredLocations = thoothukudiLocations.filter(
              location => location.name.toLowerCase().includes(searchQuery.toLowerCase())
            );
            setSearchResults(filteredLocations);
            setShowSearchResults(filteredLocations.length > 0);
          }
          setIsSearching(false);
        });
      } catch (error) {
        console.error('Google Places API error', error);
        // Fallback to predefined Thoothukudi locations
        const filteredLocations = thoothukudiLocations.filter(
          location => location.name.toLowerCase().includes(searchQuery.toLowerCase())
        );
        setSearchResults(filteredLocations);
        setShowSearchResults(filteredLocations.length > 0);
        setIsSearching(false);
      }
    } else {
      // Fallback to predefined Thoothukudi locations
      const filteredLocations = thoothukudiLocations.filter(
        location => location.name.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setSearchResults(filteredLocations);
      setShowSearchResults(filteredLocations.length > 0);
      setIsSearching(false);
    }
  }, [searchQuery, isLoaded]);

  // Handle search result click
  const handleSearchResultClick = (place: SearchPlace) => {
    if (mapRef.current) {
      // Pan to the location
      mapRef.current.panTo(place.location);
      mapRef.current.setZoom(16); // Zoom in closer
      setShowSearchResults(false); // Hide search results
    }
  };

  // Callback for when the map is loaded
  const onMapLoad = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    
    // Get user location if available
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const newPos = { lat: latitude, lng: longitude };
          setUserPosition(newPos);
          map.panTo(newPos);
          sendLocationUpdate(latitude, longitude);
        },
        (err) => {
          console.warn('Geolocation error:', err);
          // Still send default location if geolocation fails
          sendLocationUpdate(defaultCenter.lat, defaultCenter.lng);
        }
      );
    } else {
      // Use default location if geolocation not supported
      sendLocationUpdate(defaultCenter.lat, defaultCenter.lng);
    }
  }, [mapRef, sendLocationUpdate]);

  // Set up geolocation tracking
  useEffect(() => {
    let watchId: number | null = null;

    if (isLoaded && navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserPosition({ lat: latitude, lng: longitude });
          sendLocationUpdate(latitude, longitude);
        },
        (error) => {
          console.error('Error tracking location:', error);
        },
        {
          enableHighAccuracy: true,
          maximumAge: 10000,
          timeout: 10000
        }
      );
    }

    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [isLoaded, mapRef, sendLocationUpdate]);

  // Import StaticMapFallback at the top of the file
  const StaticMapFallback = React.lazy(() => import('./StaticMapFallback'));

  // Handle map load error - create more friendly message
  if (loadError) {
    // Check specifically for billing error
    const isBillingError = loadError.message?.includes('BillingNotEnabled') || 
                         loadError.message?.includes('billing');
    
    console.warn("Google Maps loading error:", loadError.message);
    
    if (isBillingError) {
      // Use our static fallback component that works without Google Maps
      return (
        <React.Suspense fallback={
          <div className="map-container w-full h-full flex items-center justify-center bg-slate-100">
            <div className="text-center p-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
              <p className="mt-2 text-sm text-gray-600">Loading fallback map...</p>
            </div>
          </div>
        }>
          <StaticMapFallback 
            routes={routes} 
            selectedRoute={selectedRoute}
            onSelectRoute={selectRoute}
          />
        </React.Suspense>
      );
    }
    
    // Generic error for other issues
    return (
      <div className="map-container w-full h-full flex flex-col items-center justify-center bg-slate-100">
        <div className="p-6 max-w-md bg-white rounded-lg shadow-md text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-700 mb-2">Map Loading Issue</h2>
          <p className="text-gray-700">We're having trouble loading our map service at the moment.</p>
          <p className="mt-3 text-gray-600">
            All SafeRoute features will continue to work with our static map data for Thoothukudi.
          </p>
          <div className="mt-4 p-3 bg-gray-50 rounded-md border border-gray-200">
            <p className="text-xs text-gray-500">
              Technical details: {loadError.message}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Show error message if map failed to load for other reasons
  if (mapError) {
    return (
      <div className="map-container w-full h-full flex flex-col items-center justify-center bg-slate-100">
        <div className="p-6 max-w-md bg-white rounded-lg shadow-md text-center">
          <AlertCircle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-red-700 mb-2">Map Loading Error</h2>
          <p className="text-gray-700">{mapError}</p>
          <p className="mt-4 text-sm text-gray-500">
            Please check your internet connection or try again later.
          </p>
        </div>
      </div>
    );
  }

  // Show loading state if not yet loaded
  if (!isLoaded) {
    return (
      <div className="map-container w-full h-full flex items-center justify-center bg-slate-100">
        <div className="text-center p-4 max-w-md">
          <div className="bg-white p-6 rounded-lg shadow-md">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto" />
            <h3 className="text-lg font-semibold mt-4 mb-2">Loading SafeRoute Map</h3>
            <p className="text-gray-600 mb-4">
              We're preparing the map of Thoothukudi with all safety information. This will just take a moment...
            </p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-4">
              <div className="bg-primary h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="map-container w-full h-full relative">
      {/* User guidance notification */}
      <div className="absolute top-4 left-1/2 transform -translate-x-1/2 z-10 px-4 py-2 bg-white rounded-lg shadow-lg text-sm text-center">
        <p className="font-medium text-primary">Use the sidebar panel to search for safe routes in Thoothukudi</p>
      </div>
      
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={userPosition}
        zoom={defaultZoom}
        options={mapOptions}
        onLoad={onMapLoad}
        onUnmount={() => {
          mapRef.current = null;
        }}
      >
        {/* User position marker */}
        <Marker
          position={userPosition}
          icon={{
            url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png',
            scaledSize: new google.maps.Size(40, 40)
          }}
          title="Your Location"
        />

        {/* Emergency Services Markers */}
        {nearbyEmergencyServices?.map((service, index) => (
          <Marker
            key={`service-${service.id}-${index}`}
            position={{ lat: service.latitude, lng: service.longitude }}
            icon={{
              url: service.type === 'police' 
                ? 'https://maps.google.com/mapfiles/ms/icons/police.png' 
                : 'https://maps.google.com/mapfiles/ms/icons/hospitals.png',
              scaledSize: new google.maps.Size(32, 32)
            }}
            onClick={() => setSelectedMarker(service)}
          />
        ))}
        
        {/* Crime Incident Markers */}
        {nearbyCrimeIncidents?.map((incident, index) => (
          <Marker
            key={`incident-${incident.id}-${index}`}
            position={{ lat: incident.latitude, lng: incident.longitude }}
            icon={{
              url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png',
              scaledSize: new google.maps.Size(24, 24)
            }}
            onClick={() => setSelectedMarker(incident)}
          />
        ))}
        
        {/* Thoothukudi Checkpoint Markers */}
        {thoothukudiLocations.map((location, index) => (
          <Marker
            key={`checkpoint-${index}`}
            position={location.location}
            icon={{
              url: 'https://maps.google.com/mapfiles/ms/icons/yellow-dot.png',
              scaledSize: new google.maps.Size(24, 24)
            }}
            title={location.name}
            onClick={() => {
              // Create a marker object with the right properties for InfoWindow
              const checkpoint = {
                id: index,
                latitude: location.location.lat,
                longitude: location.location.lng,
                name: location.name,
                type: 'checkpoint',
                description: location.address,
                address: location.address
              };
              setSelectedMarker(checkpoint as any);
            }}
          />
        ))}
        
        {/* Routes as Polylines with Safety Color Coding */}
        {routeGeoJSON.map((route, index) => {
          try {
            // Safely get coordinates and handle empty or invalid data
            const coordinates = route.geometry.coordinates || [];
            if (coordinates.length < 2) {
              console.warn(`Route ${index} has insufficient coordinates`);
              return null; // Skip this route if coordinates are invalid
            }
            
            // Convert GeoJSON coordinates (which are [lng, lat]) to Google Maps LatLng (which are {lat, lng})
            const path = coordinates.map(coord => {
              if (!Array.isArray(coord) || coord.length < 2) {
                return null; // Skip invalid coordinates
              }
              return {
                lat: coord[1],
                lng: coord[0]
              };
            }).filter(point => point !== null) as google.maps.LatLngLiteral[];
            
            if (path.length < 2) {
              console.warn(`Route ${index} has insufficient valid coordinates after processing`);
              return null; // Skip this route if not enough valid coordinates
            }
            
            // Determine if this is the selected route
            const isSelected = selectedRoute && selectedRoute.id === routes[index]?.id;
            
            // Get route color based on safety level
            const safetyLevel = route.properties.safety_level;
            const color = getSafetyLevelColor(safetyLevel);
            
            // Set stroke appearance based on selection state and safety level
            const strokeColor = color;
            const strokeWeight = isSelected ? 6 : 4;
            const strokeOpacity = isSelected ? 1 : 0.7;
            
            // Use dashed lines for moderate routes and dotted for dangerous routes
            let icons;
            if (safetyLevel === 'moderate') {
              icons = [{
                icon: {
                  path: 'M 0,-1 0,1',
                  strokeOpacity: 1,
                  scale: 3
                },
                offset: '0',
                repeat: '20px'
              }];
            } else if (safetyLevel === 'danger') {
              icons = [{
                icon: {
                  path: 'M 0,-1 0,1',
                  strokeOpacity: 1,
                  scale: 2
                },
                offset: '0',
                repeat: '10px'
              }];
            }
            
            return (
              <Polyline
                key={`route-${index}`}
                path={path}
                options={{
                  strokeColor,
                  strokeWeight,
                  strokeOpacity,
                  zIndex: isSelected ? 2 : 1,
                  clickable: true,
                  icons: icons,
                }}
                onClick={() => {
                  if (routes[index]) {
                    // Create a reference to the route before passing it to the function
                    const routeToSelect = routes[index];
                    // Call the function with the route
                    console.log('Selecting route:', routeToSelect.name);
                    selectRoute(routeToSelect);
                  }
                }}
              />
            );
          } catch (error) {
            console.error(`Error rendering route ${index}:`, error);
            return null; // Skip rendering this route in case of errors
          }
        }).filter(Boolean)}
        
        {/* Google Maps Directions Service and Renderer */}
        {directionsOptions && (
          <DirectionsService
            options={directionsOptions}
            callback={(result, status) => {
              if (status === google.maps.DirectionsStatus.OK && result) {
                setDirectionsResponse(result);
                
                // Log route details for debugging
                console.log('Directions result:', result);
                
                // Clear the options so it doesn't re-request
                setDirectionsOptions(null);
                
                if (directionsCallback) {
                  directionsCallback();
                }
              } else {
                console.error('Direction service failed with status:', status);
                setDirectionsOptions(null);
                if (directionsCallback) {
                  directionsCallback();
                }
              }
            }}
          />
        )}
        
        {directionsResponse && (
          <DirectionsRenderer
            options={{
              directions: directionsResponse,
              routeIndex: 0,
              polylineOptions: {
                strokeColor: getSafetyLevelColor(selectedRoute?.safety_level || 'moderate'),
                strokeWeight: 6,
                strokeOpacity: 0.8
              },
              markerOptions: {
                icon: {
                  url: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png',
                  scaledSize: new google.maps.Size(32, 32)
                }
              }
            }}
          />
        )}
        
        {/* InfoWindow for selected marker */}
        {selectedMarker && (
          <InfoWindow
            position={{ 
              lat: selectedMarker.latitude, 
              lng: selectedMarker.longitude 
            }}
            onCloseClick={() => setSelectedMarker(null)}
          >
            <div className="p-2 max-w-xs">
              {/* Service Location Info */}
              {'type' in selectedMarker && 'name' in selectedMarker && selectedMarker.type !== 'checkpoint' && (
                <>
                  <h3 className="font-bold text-sm">{selectedMarker.name}</h3>
                  <p className="text-xs mt-1">Type: {selectedMarker.type}</p>
                  {'contact' in selectedMarker && (
                    <p className="text-xs mt-1">Contact: {selectedMarker.contact}</p>
                  )}
                  {'operating_hours' in selectedMarker && (
                    <p className="text-xs mt-1">Hours: {selectedMarker.operating_hours}</p>
                  )}
                  {'distance' in selectedMarker && (
                    <p className="text-xs mt-1">Distance: {String(selectedMarker.distance)} km</p>
                  )}
                </>
              )}
              
              {/* Checkpoint Info */}
              {'type' in selectedMarker && selectedMarker.type === 'checkpoint' && (
                <>
                  <h3 className="font-bold text-sm">{selectedMarker.name}</h3>
                  <p className="text-xs mt-1">{selectedMarker.address}</p>
                  <div className="mt-2 text-xs flex items-center text-green-600">
                    <svg className="w-3 h-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    Safe checkpoint verified
                  </div>
                </>
              )}
              
              {/* Crime Incident Info */}
              {'incident_type' in selectedMarker && (
                <>
                  <h3 className="font-bold text-sm capitalize">{selectedMarker.incident_type} Incident</h3>
                  <p className="text-xs mt-1">
                    {selectedMarker.description}
                  </p>
                  <p className="text-xs mt-1">
                    Reported: {new Date(selectedMarker.incident_date).toLocaleDateString()} 
                    {' '}({selectedMarker.time_of_day})
                  </p>
                  <p className="text-xs mt-1">
                    Severity: {selectedMarker.severity}/10
                  </p>
                </>
              )}
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </div>
  );
};

export default MapContainer;