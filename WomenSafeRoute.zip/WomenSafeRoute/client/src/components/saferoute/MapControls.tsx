import React from 'react';

interface MapControlsProps {
  toggleSidebar: () => void;
}

const MapControls: React.FC<MapControlsProps> = ({ toggleSidebar }) => {
  return (
    <div className="absolute top-0 left-0 right-0 z-10 p-4 md:left-64 md:right-80">
      <div className="flex justify-between items-center">
        {/* App Title */}
        <div className="flex items-center space-x-2">
          <h1 className="text-lg font-semibold bg-white py-1 px-3 rounded-md shadow-md text-primary md:text-xl">SafeRoute Delhi</h1>
        </div>
        
        {/* Search Bar */}
        <div className="flex-grow mx-4 max-w-md hidden md:block">
          <div className="relative">
            <input 
              type="text" 
              placeholder="Search location..." 
              className="w-full py-2 pl-10 pr-4 rounded-lg shadow-md border-none focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <span className="material-icons absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400">search</span>
          </div>
        </div>
        
        {/* Action Buttons for Desktop */}
        <div className="hidden md:flex space-x-2">
          <button 
            className="bg-white p-2 rounded-full shadow-lg text-primary hover:bg-gray-100 focus:outline-none" 
            title="Settings"
          >
            <span className="material-icons">settings</span>
          </button>
          <button 
            className="bg-white p-2 rounded-full shadow-lg text-primary hover:bg-gray-100 focus:outline-none" 
            title="Notifications"
          >
            <span className="material-icons">notifications</span>
          </button>
          <button 
            className="bg-white p-2 rounded-full shadow-lg text-primary hover:bg-gray-100 focus:outline-none" 
            title="Profile"
          >
            <span className="material-icons">account_circle</span>
          </button>
        </div>
      </div>
      
      {/* Mobile Search Bar (Only visible on mobile) */}
      <div className="mt-2 md:hidden">
        <div className="relative">
          <input 
            type="text" 
            placeholder="Search location..." 
            className="w-full py-2 pl-10 pr-4 rounded-lg shadow-md border-none focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <span className="material-icons absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400">search</span>
        </div>
      </div>
    </div>
  );
};

export default MapControls;
