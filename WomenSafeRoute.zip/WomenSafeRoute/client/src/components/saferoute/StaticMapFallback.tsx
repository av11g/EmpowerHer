import React from 'react';
import { Layers, Map, MapPin, Navigation, AlertCircle, Shield } from 'lucide-react';
import { thoothukudiLocations } from './MapContainer';
import { getSafetyLevelColor } from '@/utils/color-utils';
import type { Route } from '@shared/schema';

interface StaticMapFallbackProps {
  routes: Route[];
  selectedRoute: Route | null;
  onSelectRoute: (route: Route) => void;
}

const StaticMapFallback: React.FC<StaticMapFallbackProps> = ({ 
  routes, 
  selectedRoute, 
  onSelectRoute 
}) => {
  return (
    <div className="flex flex-col h-full w-full overflow-hidden bg-gray-100">
      {/* Static map header */}
      <div className="bg-white p-4 shadow-md flex items-center justify-between">
        <div className="flex items-center">
          <Map className="h-5 w-5 text-primary mr-2" />
          <h3 className="font-medium text-gray-800">Thoothukudi Safety Map</h3>
        </div>
        <span className="text-xs px-2 py-1 bg-amber-100 text-amber-800 rounded-full">
          Offline Mode
        </span>
      </div>

      {/* Static map area */}
      <div className="flex-1 p-4 overflow-auto">
        <div className="bg-white rounded-lg shadow p-4 mb-4">
          <h4 className="font-medium text-sm text-gray-700 mb-2">Map Information</h4>
          <p className="text-xs text-gray-600 mb-2">
            The interactive map is currently unavailable, but all safety features 
            continue to work using our local data for Thoothukudi.
          </p>
          <div className="grid grid-cols-2 gap-2 mb-2">
            <div className="bg-blue-50 p-2 rounded flex items-center text-xs text-blue-700">
              <MapPin className="h-3 w-3 mr-1" />
              <span>15 Safe Checkpoints</span>
            </div>
            <div className="bg-green-50 p-2 rounded flex items-center text-xs text-green-700">
              <Shield className="h-3 w-3 mr-1" />
              <span>24 Emergency Points</span>
            </div>
          </div>
        </div>

        {/* Thoothukudi locations list */}
        <div className="bg-white rounded-lg shadow mb-4">
          <div className="p-3 border-b border-gray-100 flex items-center">
            <Layers className="h-4 w-4 text-gray-500 mr-2" />
            <h4 className="font-medium text-sm text-gray-700">Thoothukudi Safe Locations</h4>
          </div>
          <div className="divide-y divide-gray-100 max-h-60 overflow-y-auto">
            {thoothukudiLocations.map((location, index) => (
              <div key={index} className="p-3 hover:bg-gray-50 cursor-pointer">
                <h5 className="font-medium text-sm text-gray-800">{location.name}</h5>
                <p className="text-xs text-gray-500">{location.address}</p>
                <div className="flex items-center mt-1">
                  <span className="inline-block w-2 h-2 bg-green-500 rounded-full mr-1"></span>
                  <span className="text-xs text-green-600">Safe Location</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Available routes */}
        <div className="bg-white rounded-lg shadow">
          <div className="p-3 border-b border-gray-100 flex items-center">
            <Navigation className="h-4 w-4 text-gray-500 mr-2" />
            <h4 className="font-medium text-sm text-gray-700">Available Safe Routes</h4>
          </div>
          <div className="divide-y divide-gray-100 max-h-80 overflow-y-auto">
            {routes.map((route) => {
              const isSelected = selectedRoute?.id === route.id;
              const safetyColor = getSafetyLevelColor(route.safety_level);
              
              return (
                <div 
                  key={route.id} 
                  className={`p-3 hover:bg-gray-50 cursor-pointer ${isSelected ? 'bg-gray-50' : ''}`}
                  onClick={() => onSelectRoute(route)}
                >
                  <div className="flex justify-between items-center">
                    <h5 className="font-medium text-sm text-gray-800">{route.name}</h5>
                    <span 
                      className="px-2 py-0.5 rounded-full text-xs font-medium"
                      style={{ 
                        backgroundColor: `${safetyColor}20`, 
                        color: safetyColor 
                      }}
                    >
                      {route.safety_level}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    {route.distance.toFixed(1)} km • {Math.round(route.duration / 60)} min
                  </p>
                  <div className="mt-2 flex gap-2">
                    <div className="text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-600">
                      {route.lighting}
                    </div>
                    <div className="text-xs bg-gray-100 px-1.5 py-0.5 rounded text-gray-600">
                      {route.foot_traffic}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Static footer */}
      <div className="bg-amber-50 border-t border-amber-100 p-3 flex items-start">
        <AlertCircle className="h-4 w-4 text-amber-500 mr-2 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-amber-700">
          You're viewing offline data for Thoothukudi. Map interactivity is limited, 
          but all safety features and route information is available.
        </p>
      </div>
    </div>
  );
};

export default StaticMapFallback;