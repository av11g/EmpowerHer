import React, { useState, useEffect } from 'react';
import { useWebSocket } from '@/hooks/use-websocket';
import { Badge } from '@/components/ui/badge';
import { getSafetyLevelFromScore, getSafetyLevelColor } from '@/utils/color-utils';

const SafetyNotifications: React.FC = () => {
  const {
    isConnected,
    lastSafetyUpdate,
    nearbyEmergencyServices,
    communityAlerts
  } = useWebSocket();
  
  const [showNotifications, setShowNotifications] = useState(false);
  
  // Toggle notifications panel
  const toggleNotifications = () => {
    setShowNotifications(prev => !prev);
  };
  
  // Close notifications when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const target = event.target as HTMLElement;
      if (!target.closest('.notifications-panel') && !target.closest('.notifications-toggle')) {
        setShowNotifications(false);
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  
  // Format timestamp
  const formatTimestamp = (timestamp: string): string => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };
  
  return (
    <div className="notifications-container">
      {/* Notification Toggle Button */}
      <button 
        className="notifications-toggle fixed top-4 right-4 z-50 bg-white shadow-md rounded-full w-12 h-12 flex items-center justify-center"
        onClick={toggleNotifications}
      >
        <div className="relative">
          <span className="material-icons text-gray-700">notifications</span>
        </div>
      </button>
      
      {/* Notifications Panel */}
      {showNotifications && (
        <div className="notifications-panel fixed top-20 right-4 z-50 bg-white shadow-lg rounded-lg w-80 max-h-[calc(100vh-120px)] overflow-y-auto">
          <div className="p-4 border-b">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Real-time Safety Updates</h3>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Receiving live safety updates
            </p>
          </div>
          
          {/* Latest Safety Score */}
          {lastSafetyUpdate && (
            <div className="p-4 border-b">
              <h4 className="text-sm font-medium">Latest Safety Update</h4>
              <div className="mt-2 p-3 bg-gray-50 rounded-md">
                <div className="flex items-center justify-between">
                  <Badge
                    className="text-xs"
                    style={{ backgroundColor: getSafetyLevelColor(getSafetyLevelFromScore(lastSafetyUpdate.score)) }}
                  >
                    {getSafetyLevelFromScore(lastSafetyUpdate.score)}
                  </Badge>
                  <span className="text-xs text-gray-500">{lastSafetyUpdate.time_of_day}</span>
                </div>
                <div className="mt-2">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="h-2 rounded-full" 
                      style={{ 
                        width: `${lastSafetyUpdate.score}%`,
                        backgroundColor: getSafetyLevelColor(getSafetyLevelFromScore(lastSafetyUpdate.score))
                      }}
                    ></div>
                  </div>
                  <div className="flex justify-between mt-1">
                    <span className="text-xs">Safety Score</span>
                    <span className="text-xs font-medium">{lastSafetyUpdate.score}/100</span>
                  </div>
                </div>
                <div className="mt-2 flex items-center text-xs text-gray-500">
                  <div className="flex items-center mr-3">
                    <span className="material-icons text-xs mr-1">light</span>
                    <span>Lighting: {lastSafetyUpdate.lighting_level}/10</span>
                  </div>
                  <div className="flex items-center">
                    <span className="material-icons text-xs mr-1">group</span>
                    <span>Foot Traffic: {lastSafetyUpdate.foot_traffic}/10</span>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Nearby Emergency Services */}
          {nearbyEmergencyServices && nearbyEmergencyServices.length > 0 && (
            <div className="p-4 border-b">
              <h4 className="text-sm font-medium">Nearby Emergency Services</h4>
              <div className="mt-2 space-y-2">
                {nearbyEmergencyServices.map((service, index) => (
                  <div key={index} className="p-2 bg-gray-50 rounded-md flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                      service.type === 'police' ? 'bg-blue-100 text-blue-500' : 'bg-green-100 text-green-500'
                    }`}>
                      <span className="material-icons text-sm">
                        {service.type === 'police' ? 'local_police' : 'local_hospital'}
                      </span>
                    </div>
                    <div className="ml-2 flex-1">
                      <p className="text-xs font-medium">{service.name}</p>
                      <p className="text-xs text-gray-500">{service.distance} km away</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Community Alerts */}
          {communityAlerts.length > 0 && (
            <div className="p-4">
              <h4 className="text-sm font-medium">Community Alerts</h4>
              <div className="mt-2 space-y-3">
                {communityAlerts.map((alert, index) => (
                  <div key={index} className="p-3 bg-red-50 rounded-md">
                    <div className="flex items-center justify-between">
                      <Badge variant="destructive" className="text-xs">
                        {alert.alertType.toUpperCase()}
                      </Badge>
                      <span className="text-xs text-gray-500">{formatTimestamp(alert.timestamp)}</span>
                    </div>
                    <p className="text-sm mt-2">{alert.message}</p>
                    <p className="text-xs text-gray-500 mt-1">
                      Location: {alert.location.latitude.toFixed(4)}, {alert.location.longitude.toFixed(4)}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {/* Empty State */}
          {!lastSafetyUpdate && !nearbyEmergencyServices && communityAlerts.length === 0 && (
            <div className="p-8 text-center">
              <span className="material-icons text-4xl text-gray-300">notifications_none</span>
              <p className="mt-2 text-sm text-gray-500">No notifications yet</p>
              <p className="text-xs text-gray-400 mt-1">Safety updates will appear here</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SafetyNotifications;