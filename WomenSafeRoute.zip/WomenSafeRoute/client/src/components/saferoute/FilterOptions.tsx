import React from 'react';

interface FilterOptionsProps {
  visibleServiceTypes: Set<string>;
  toggleServiceType: (type: string) => void;
}

const FilterOptions: React.FC<FilterOptionsProps> = ({
  visibleServiceTypes,
  toggleServiceType
}) => {
  const isActive = (type: string) => visibleServiceTypes.has(type);

  return (
    <div className="absolute top-20 right-4 z-10 md:right-96">
      <div className="bg-white rounded-lg shadow-lg p-2">
        <button 
          className={`${isActive('police') ? 'bg-blue-500' : 'bg-gray-300'} p-2 rounded-full shadow text-white hover:bg-blue-600 focus:outline-none`} 
          title="Show Police Stations"
          onClick={() => toggleServiceType('police')}
        >
          <span className="material-icons">local_police</span>
        </button>
        <button 
          className={`${isActive('hospital') ? 'bg-red-500' : 'bg-gray-300'} p-2 rounded-full shadow text-white hover:bg-red-600 focus:outline-none mt-2`} 
          title="Show Hospitals"
          onClick={() => toggleServiceType('hospital')}
        >
          <span className="material-icons">local_hospital</span>
        </button>
        <button 
          className={`${isActive('restaurant') ? 'bg-orange-500' : 'bg-gray-300'} p-2 rounded-full shadow text-white hover:bg-orange-600 focus:outline-none mt-2`} 
          title="Show Restaurants"
          onClick={() => toggleServiceType('restaurant')}
        >
          <span className="material-icons">restaurant</span>
        </button>
        <button 
          className="bg-gray-700 p-2 rounded-full shadow text-white hover:bg-gray-800 focus:outline-none mt-2" 
          title="Show All"
          onClick={() => {
            // Toggle all service types
            const allTypes = ['police', 'hospital', 'restaurant'];
            const allVisible = allTypes.every(type => visibleServiceTypes.has(type));
            
            if (allVisible) {
              // Hide all if all are visible
              allTypes.forEach(type => toggleServiceType(type));
            } else {
              // Show all if any are hidden
              allTypes.forEach(type => {
                if (!visibleServiceTypes.has(type)) {
                  toggleServiceType(type);
                }
              });
            }
          }}
        >
          <span className="material-icons">layers</span>
        </button>
      </div>
    </div>
  );
};

export default FilterOptions;
