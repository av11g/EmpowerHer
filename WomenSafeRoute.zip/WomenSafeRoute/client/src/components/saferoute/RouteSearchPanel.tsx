import React, { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Route } from '@shared/schema';
import { Loader2, Search, MapPin, LocateFixed, ArrowRightCircle, AlertTriangle, Navigation } from 'lucide-react';
import { getSafetyLevelColor } from '@/utils/color-utils';
import { useSafetyMap } from '@/hooks/use-safety-map';
import { thoothukudiLocations } from './MapContainer';

interface RouteSearchPanelProps {
  routes: Route[];
  selectedRoute: Route | null;
  selectRoute: (route: Route) => void;
  isLoading: boolean;
}

// Get just the names of locations for autocomplete suggestions
const locationNames = thoothukudiLocations.map(location => location.name);

const RouteSearchPanel: React.FC<RouteSearchPanelProps> = ({
  routes,
  selectedRoute,
  selectRoute,
  isLoading,
}) => {
  const { searchForRoute, centerMapOnCoordinates } = useSafetyMap();
  const [source, setSource] = useState<string>('Thoothukudi Bus Stand');
  const [destination, setDestination] = useState<string>('');
  const [searched, setSearched] = useState<boolean>(false);
  const [filteredRoutes, setFilteredRoutes] = useState<Route[]>([]);
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Filter routes when source or destination changes
  useEffect(() => {
    if (searched && source && destination) {
      const matchingRoutes = searchForRoute(source, destination);
      setFilteredRoutes(matchingRoutes || []);
      
      // If we found routes, select the first one
      if (matchingRoutes && matchingRoutes.length > 0) {
        selectRoute(matchingRoutes[0]);
        setSearchError(null);
      } else {
        setSearchError("No routes found for these locations. Try using locations from the suggestions.");
      }
    }
  }, [searched, source, destination, searchForRoute, selectRoute]);

  // Function to find a location by name in the Thoothukudi locations array
  const findLocationCoordinates = useCallback((locationName: string): google.maps.LatLngLiteral | null => {
    // Find the matching location in our Thoothukudi locations data
    const locationObj = thoothukudiLocations.find(
      loc => loc.name.toLowerCase() === locationName.toLowerCase()
    );
    
    if (locationObj) {
      // Return the coordinates
      return locationObj.location;
    }
    
    return null;
  }, []);
  
  // Handle search button click
  const handleSearch = () => {
    if (source && destination) {
      setIsSearching(true);
      setSearched(true);
      
      // Simulate loading
      setTimeout(() => {
        setIsSearching(false);
        
        // Attempt to fetch matching routes from our database using the search function
        const matchingRoutes = searchForRoute(source, destination);
        setFilteredRoutes(matchingRoutes || []);
        
        // If we found routes, select the first one
        if (matchingRoutes && matchingRoutes.length > 0) {
          selectRoute(matchingRoutes[0]);
          setSearchError(null);
        } else {
          setSearchError("No routes found for these locations. Try using locations from the suggestions.");
        }
      }, 800);
    }
  };

  // Format location name for display
  const formatLocationName = (name: string): string => {
    return name.replace(/thoothukudi/i, '').trim(); // Remove "Thoothukudi" from display
  };

  // Handle source selection with suggestion logic
  const handleSourceChange = (value: string) => {
    setSource(value);
    
    // If the user started typing, show suggestions
    if (value && value.length > 1) {
      const suggestions = locationNames.filter(
        loc => loc.toLowerCase().includes(value.toLowerCase())
      );
      
      // If we have exactly one suggestion and it's very close to what the user typed
      if (suggestions.length === 1 && suggestions[0].toLowerCase().startsWith(value.toLowerCase())) {
        // Auto-complete if it's a strong match
        if (value.length > 3) {
          setSource(suggestions[0]);
        }
      }
    }
  };

  // Handle destination selection with suggestion logic  
  const handleDestinationChange = (value: string) => {
    setDestination(value);
    
    // If the user started typing, show suggestions
    if (value && value.length > 1) {
      const suggestions = locationNames.filter(
        loc => loc.toLowerCase().includes(value.toLowerCase())
      );
      
      // If we have exactly one suggestion and it's very close to what the user typed
      if (suggestions.length === 1 && suggestions[0].toLowerCase().startsWith(value.toLowerCase())) {
        // Auto-complete if it's a strong match
        if (value.length > 3) {
          setDestination(suggestions[0]);
        }
      }
    }
  };

  // Use current location as source
  const useCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Use Thoothukudi Bus Stand as default since we're building for Thoothukudi
          setSource("Thoothukudi Bus Stand");
          setSearchError(null);
        },
        (error) => {
          console.error("Error getting location:", error);
          setSource("Thoothukudi Bus Stand"); // Fallback
        }
      );
    } else {
      setSource("Thoothukudi Bus Stand"); // Fallback
    }
  };

  // Handle swap source and destination
  const swapLocations = () => {
    const temp = source;
    setSource(destination);
    setDestination(temp);
    
    // If already searched, trigger new search
    if (searched) {
      setSearched(false);
      setTimeout(() => {
        setSearched(true);
      }, 100);
    }
  };

  return (
    <Card className="w-full bg-white shadow-md">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-semibold">Find Safe Routes in Thoothukudi</CardTitle>
        <p className="text-xs text-gray-500 mt-1">
          Enter your starting point and destination to find the safest route
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          <div className="flex space-x-2 items-center">
            <div className="flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 flex-shrink-0">
              <MapPin className="h-4 w-4 text-primary" />
            </div>
            <Input
              placeholder="Enter starting point"
              value={source}
              onChange={(e) => handleSourceChange(e.target.value)}
              list="source-locations"
              className="flex-1"
            />
            <datalist id="source-locations">
              {locationNames.map((locationName, i) => (
                <option key={`source-${i}`} value={locationName} />
              ))}
            </datalist>
            <Button 
              size="sm" 
              variant="ghost" 
              className="px-2" 
              onClick={useCurrentLocation}
              title="Use current location"
            >
              <LocateFixed className="h-4 w-4 text-gray-500" />
            </Button>
          </div>
          
          <div className="relative">
            <div className="absolute left-3.5 top-1/2 transform -translate-y-1/2 z-10">
              <Button
                size="sm"
                variant="ghost"
                className="h-6 w-6 p-0 rounded-full"
                onClick={swapLocations}
                title="Swap source and destination"
              >
                <ArrowRightCircle className="h-5 w-5 text-gray-400 rotate-90" />
              </Button>
            </div>
          </div>
          
          <div className="flex space-x-2 items-center">
            <div className="flex items-center justify-center h-7 w-7 rounded-full bg-orange-100 flex-shrink-0">
              <MapPin className="h-4 w-4 text-orange-500" />
            </div>
            <Input
              placeholder="Enter destination"
              value={destination}
              onChange={(e) => handleDestinationChange(e.target.value)}
              list="destination-locations"
              className="flex-1"
            />
            <datalist id="destination-locations">
              {locationNames.map((locationName, i) => (
                <option key={`dest-${i}`} value={locationName} />
              ))}
            </datalist>
          </div>
          
          <div className="pt-1">
            <Button 
              className="w-full bg-gradient-to-r from-primary to-primary/80" 
              onClick={handleSearch}
              disabled={!source || !destination || isSearching}
            >
              {isSearching ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Searching...
                </>
              ) : (
                <>
                  <Search className="mr-2 h-4 w-4" />
                  Find Safe Routes
                </>
              )}
            </Button>
            <p className="text-xs text-center text-gray-500 mt-2">
              Routes are color-coded by safety level: green (safe), amber (moderate), red (danger)
            </p>
          </div>
        </div>

        {/* Search Results */}
        {searched && (
          <>
            {searchError ? (
              <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-100">
                <div className="flex items-start">
                  <AlertTriangle className="h-5 w-5 text-red-400 mr-2 mt-0.5" />
                  <div>
                    <p className="text-sm text-red-700">{searchError}</p>
                    <p className="text-xs text-red-500 mt-1">
                      Try using locations like "Thoothukudi Bus Stand", "VOC Port", etc.
                    </p>
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-4">
                <h3 className="text-sm font-medium mb-2">
                  {filteredRoutes.length > 0 
                    ? `${filteredRoutes.length} routes found` 
                    : 'No routes found for this search'}
                </h3>
                
                <div className="space-y-3">
                  {filteredRoutes.map((route) => {
                    const isSelected = selectedRoute?.id === route.id;
                    const safetyColor = getSafetyLevelColor(route.safety_level);
                    
                    // Get icon for lighting and foot traffic
                    const lightingDescription = route.lighting === 'well-lit' 
                      ? 'Well-lit streets'
                      : route.lighting === 'partially lit'
                      ? 'Partially lit streets'
                      : 'Poor lighting conditions';
                    
                    const footTrafficDescription = route.foot_traffic === 'high'
                      ? 'High foot traffic area'
                      : route.foot_traffic === 'moderate'
                      ? 'Moderate foot traffic'
                      : 'Low foot traffic area';
                      
                    return (
                      <div
                        key={route.id}
                        className={`p-3 rounded-lg cursor-pointer border transition-all ${
                          isSelected 
                            ? 'border-primary shadow-sm bg-primary/5' 
                            : 'border-gray-200 hover:border-gray-300 hover:shadow-sm hover:bg-gray-50'
                        }`}
                        onClick={() => selectRoute(route)}
                      >
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium text-sm">{route.name}</h4>
                            
                            {/* From/To simplified representation */}
                            <div className="flex items-center mt-1.5 text-xs text-gray-500">
                              <div className="flex items-center">
                                <span className="inline-block h-2 w-2 rounded-full bg-primary mr-1"></span>
                                {formatLocationName(source)}
                              </div>
                              <svg className="h-3 w-3 mx-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                                <path d="M5 12h14" strokeLinecap="round" strokeLinejoin="round" />
                                <path d="M13 5l7 7-7 7" strokeLinecap="round" strokeLinejoin="round" />
                              </svg>
                              <div className="flex items-center">
                                <span className="inline-block h-2 w-2 rounded-full bg-orange-400 mr-1"></span>
                                {formatLocationName(destination)}
                              </div>
                            </div>
                            
                            {/* Safety indicator */}
                            <div className="flex items-center mt-2">
                              <div 
                                className={`w-16 h-1.5 rounded-full overflow-hidden bg-gray-200 mr-2`}
                              >
                                <div 
                                  className="h-full rounded-full"
                                  style={{ 
                                    width: `${route.safety_score}%`, 
                                    backgroundColor: safetyColor 
                                  }}
                                />
                              </div>
                              <span 
                                className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                                  route.safety_level === 'safe' 
                                  ? 'bg-green-100 text-green-700'
                                  : route.safety_level === 'moderate' 
                                  ? 'bg-yellow-100 text-yellow-700'
                                  : 'bg-red-100 text-red-700'
                                }`}
                              >
                                {route.safety_score}% Safe
                              </span>
                            </div>
                            
                            {/* Route details */}
                            <div className="flex flex-wrap items-center mt-2 text-xs text-gray-600">
                              <div className="flex items-center mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                                </svg>
                                {route.duration} min
                              </div>
                              <div className="flex items-center mr-3">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                                </svg>
                                {route.distance} km
                              </div>
                            </div>
                            
                            {/* Conditional safety features */}
                            <div className="mt-2 text-xs text-gray-500">
                              <div className="flex items-center mb-1">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                  <path d="M11 3a1 1 0 10-2 0v1a1 1 0 102 0V3zM15.657 5.757a1 1 0 00-1.414-1.414l-.707.707a1 1 0 001.414 1.414l.707-.707zM18 10a1 1 0 01-1 1h-1a1 1 0 110-2h1a1 1 0 011 1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zM5 10a1 1 0 01-1 1H3a1 1 0 110-2h1a1 1 0 011 1zM8 16v-1h4v1a2 2 0 11-4 0zM12 14c.015-.34.208-.646.477-.859a4 4 0 10-4.954 0c.27.213.462.519.476.859h4.002z" />
                                </svg>
                                {lightingDescription}
                              </div>
                              <div className="flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 mr-1" viewBox="0 0 20 20" fill="currentColor">
                                  <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
                                </svg>
                                {footTrafficDescription}
                              </div>
                            </div>
                          </div>
                          
                          {/* Select button for mobile */}
                          <button 
                            className={`text-xs py-1 px-2 rounded-full mt-1 ml-2 ${
                              isSelected 
                                ? 'bg-primary text-white' 
                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                            }`}
                            onClick={(e) => {
                              e.stopPropagation();
                              selectRoute(route);
                            }}
                          >
                            {isSelected ? 'Selected' : 'Select'}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default RouteSearchPanel;